% Cannibal Burger.                                               %
% By Mitsuru Igami and Nathan Yang.                              %
% Transition matrices for population and income                  %
% January 9, 2014.                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load canadafastfood_am

% Parse out data.
clusterid = data(:,1);      % Unique market ID.
year = data(:,2);           % Year.
N_aw = data(:,3);           % Number of A & W outlets (in data).
N_bk = data(:,4);           % Number of Burger King outlets (in data).
N_hvy = data(:,5);          % Number of Harvey's outlets (in data).
N_mcd = data(:,6);          % Number of McDonald's outlets (in data).
N_wdy = data(:,7);          % Number of Wendy's outlets (in data).
lagN_aw = data(:,8);        % Lagged number of A & W outlets.
lagN_bk = data(:,9);        % Lagged number of Burger King outlets.
lagN_hvy = data(:,10);      % Lagged number of Harvey's outlets. 
lagN_mcd = data(:,11);      % Lagged number of McDonald's outlets.    
lagN_wdy = data(:,12);      % Lagged number of Wendy's outlets
fwdN_aw = data(:,13);       % Forward (next period) number of A & W outlets.
fwdN_bk = data(:,14);       % Forward (next period) number of Burger King outlets.
fwdN_hvy = data(:,15);      % Forward (next period) number of Harvey's outlets.
fwdN_mcd = data(:,16);      % Forward (next period) number of McDonald's outlets.
fwdN_wdy = data(:,17);      % Forward (next period) number of Wendy's outlets.
a_aw = data(:,18);          % Action (change in number of outlets) for A & W.
a_bk = data(:,19);          % Action (change in number of outlets) for Burger King.
a_hvy = data(:,20);         % Action (change in number of outlets) for Harvey's.    
a_mcd = data(:,21);         % Action (change in number of outlets) for McDonald's.
a_wdy = data(:,22);         % Action (change in number of outlets) for Wendy's.
fsaid = data(:,23);         % FSA ID.
pop = data(:,24);           % Population.
inc = data(:,26);           % Income
val = data(:,25);           % Property value
cityid = data(:,27);        % City id (?).
lagpop = data(:,34);        % Lagged population.
laginc = data(:,35);        % Lagged income.    
lagval = data(:,36);        % Lagged property value.    
lag2pop = data(:,37);       % Lagged 2 periods population.
lag2inc = data(:,38);       % Lagged 2 periods income.
lag2val = data(:,39);       % Lagged 2 periods property value.
lag3pop = data(:,40);       % Lagged 3 periods population.
lag3inc = data(:,41);       % Lagged 3 periods income.
lag3val = data(:,42);       % Lagged 3 periods property value.
fwdpop = data(:,43);        % Forward (next period) population.
fwdinc = data(:,44);        % Forward (next period) income.    
fwdval = data(:,45);        % Forward (next period) property value.
lag2N_aw = data(:,46);      % Lagged 2 periods number of A & W.
lag2N_bk = data(:,47);      % Lagged 2 periods number of Burger King.
lag2N_hvy = data(:,48);     % Lagged 2 periods number of Harvey's.    
lag2N_mcd = data(:,49);     % Lagged 2 periods number of McDonald's.    
lag2N_wdy = data(:,50);     % Lagged 2 periods number of Wendy's.    
lag3N_aw = data(:,51);      % Lagged 3 periods number of A & W.
lag3N_bk = data(:,52);      % Lagged 3 periods number of Burger King.
lag3N_hvy = data(:,53);     % Lagged 3 periods number of Harvey's.    
lag3N_mcd = data(:,54);     % Lagged 3 periods number of McDonald's.    
lag3N_wdy = data(:,55);     % Lagged 3 periods number of Wendy's.
mktfe = data(:,56);         % FE based on Toivanen and Waterson (2005) regression.
tertile = data(:,57);       % Tertile based on FE from Toivanen and Waterson (2005).

MT = size(data,1);          % Size of the dataset (M x T).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construction of main variables.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Obtain quantiles for main market characteristics.
pop25 = quantile(pop,0.25);   
inc25 = quantile(inc,0.25);  
pop50 = quantile(pop,0.5);  
inc50 = quantile(inc,0.5);  
pop75 = quantile(pop,0.75);   
inc75 = quantile(inc,0.75);   

o = ones(length(data),1);
disc_pop = o.*0.*(pop <= pop25) + o.*1.*(pop > pop25 & pop <= pop50) + o.*2.*(pop > pop50 & pop <= pop75) + o.*3.*(pop > pop75);  
disc_inc = o.*0.*(inc <= inc25) + o.*1.*(inc > inc25 & inc <= inc50) + o.*2.*(inc > inc50 & inc <= inc75) + o.*3.*(inc > inc75);  
 
fwddisc_pop = o.*0.*(fwdpop <= pop25) + o.*1.*(fwdpop > pop25 & fwdpop <= pop50) + o.*2.*(fwdpop > pop50 & fwdpop <= pop75) + o.*3.*(fwdpop > pop75);  
fwddisc_inc = o.*0.*(fwdinc <= inc25) + o.*1.*(fwdinc > inc25 & fwdinc <= inc50) + o.*2.*(fwdinc > inc50 & fwdinc <= inc75) + o.*3.*(fwdinc > inc75);  
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construction of transition matrix.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

S = 4;
T_pop = zeros(S,S);
T_inc = zeros(S,S);

for s = 1:S
   for t = 1:S
       numer = sum(1.*(disc_pop == s-1).*1.*(fwddisc_pop == t-1));
       denom = sum(1.*(disc_pop == s-1));
       T_pop(s,t) = numer/denom;
       
       numer = sum(1.*(disc_inc == s-1).*1.*(fwddisc_inc == t-1));
       denom = sum(1.*(disc_inc == s-1));
       T_inc(s,t) = numer/denom;
   end
end    

save('T_pop.mat','T_pop');            % Save the transition matrix.
save('T_inc.mat','T_inc');  % Save the transition matrix matched with data.

