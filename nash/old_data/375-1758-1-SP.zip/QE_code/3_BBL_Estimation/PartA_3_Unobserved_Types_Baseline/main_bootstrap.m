% Dynamic Spatial Oligopoly.                                                    %
% By Mitsuru Igami and Nathan Yang.                                             %
% Main program for estimating bootstrap standard errors for AM-BBL estimates.   %
% February 12, 2014.                                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the data, states, and transition matrices.
load canadafastfood
load gamestates

% Load estimates from BBL estimation.
load Psi_kappa0_mcd_cal15
load Psi_kappa0_other_cal15
estimates_mcd = Psi_kappa0_mcd;
estimates_other = Psi_kappa0_other;

% Load the CCPs.
load P_mcd_new;                             % 1st-stage q-weighted policy function estimates for McDonald's.
load P_other_new;                           % 1st-stage q-weighted policy function estimates for others.
% Note: P_[] = P(state,action,market type)
%            = [Pr(a = -1|Low), Pr(a = 0|Low), Pr(a = +1|Low), ...
%               Pr(a = -1|Mid), Pr(a = 0|Mid), Pr(a = +1|Mid), ...
%               Pr(a = -1|High), Pr(a = 0|High), Pr(a = +1|High)]
P_mcd = [0.5*P_other_new(:,1,3), P_mcd_new(:,2,1), P_mcd_new(:,3,1), 0.5*P_other_new(:,1,2), P_mcd_new(:,2,2), P_mcd_new(:,3,2),0.5*P_other_new(:,1,1), P_mcd_new(:,2,3), P_mcd_new(:,3,3)];
P_other = [P_other_new(:,:,1), P_other_new(:,:,2), P_other_new(:,:,3)];
P_star_mcd = P_mcd;                     % Policy function [256 x 3]
P_star_other = P_other;                 % Policy function [256 x 3]

% Q matrix of posterior probabilities.
load Q_new;
Qnew = Q_new;

% Load the transition matrices for population, income, and property value.
load T_pop
load T_inc

% Initialize the game.
MT = size(data,1);          % Size of the dataset (M x T).
Player = 5;                 % Number of (symmetric) players
T = 35;                     % Number of time periods
M = MT/T;                   % Number of markets
narg = 10;                  % Number of arguments in profit & value functions 
nparam = 9;                 % Number of parameters.

% Set the total number of bootstrap samples.
numB = 1000;

% Create matrices that store parameter estimates with each bootstrap iteration.
PsiB_mcd = zeros(nparam,numB);
PsiB_other = zeros(nparam,numB);

% Load the states of the game.
Ni = states(:,1);               % Number of own outlets: {0,1,2+}.
Nj = states(:,2);               % Number of rival outlets: {0,1,2+}.
dz1 = states(:,3);              % Discretized population state: {1,2}.
dz2 = states(:,4);              % Discretized income state: {1,2}.
S = size(states,1);             % Size of the statespace.

for b = 1:numB

    % Subsample from the data.
    myseed = 645456+b;                                       % Set the seed value for randomly drawn subsamples.
    rng(myseed);                                             % Set the seed.
    markets = [1:1:M];                                       % Vector of all possible markets.
    numsamples = 300;                                        % Total number of markets drawn.
    marketsubset = randsample(markets,numsamples,false);     % Drawing the market indices.    
    dataB = datasubsamp(marketsubset,data);                  % Parse out data associated with sampled indices.
    
    P_star_mcd = P_mcd;                     % Policy function [256 x 3]
    P_star_other = P_other;                 % Policy function [256 x 3]
 
    % Calculate expected values (before multiplied by Psi) from observed policy
    fprintf('\n Calculating the expected values, of sticking to the observed policy');
    fprintf('\n ');
    tic
    [Vstar_aw, Vstar_bk, Vstar_hvy, Vstar_mcd, Vstar_wdy] = ...
        forwardsimB(P_star_mcd, P_star_other, T_pop, T_inc, dataB, Qnew(marketsubset,:)); % Find expected values by simulation
    toc

    % Calculate expected values (before multiplied by Psi) from perturbed policies
    Perturb = 1000;     % Number of perturbations, 1000

    seed = 645477;      % Seed value for random draws
    rng(seed);          % Set the seed
    perturb1 = normrnd(0, .02, length(P_mcd), Perturb, 2, 3);  % Noise to prob(-).
    perturb3 = normrnd(0, .02, length(P_mcd), Perturb, 2, 3);  % Noise to prob(+).
    perturb2 = -(perturb1 + perturb3);         

    Vtilde_aw = []; Vtilde_bk = []; Vtilde_hvy = []; Vtilde_mcd = []; Vtilde_wdy = []; % Initialize
    
    for per = 1:Perturb    % For each perturbed policy
        fprintf('\n Calculating the expected values, of using alternative policy # %2.0f:', per);
        tic
    
        noise_mcd = [perturb1(:,per,1,1), perturb2(:,per,1,1), perturb3(:,per,1,1), perturb1(:,per,1,2), perturb2(:,per,1,2), perturb3(:,per,1,2), perturb1(:,per,1,3), perturb2(:,per,1,3), perturb3(:,per,1,3)];
        noise_other = [perturb1(:,per,2,1), perturb2(:,per,2,1), perturb3(:,per,2,1), perturb1(:,per,2,2), perturb2(:,per,2,2), perturb3(:,per,2,2), perturb1(:,per,2,3), perturb2(:,per,2,3), perturb3(:,per,2,3)];

        P_tilde_mcd = P_star_mcd + noise_mcd;         % Perturbed McDonald's policy = optimal policy + noise
        P_tilde_other = P_star_other + noise_other;   % Perturbed others policy = optimal policy + noise
    
        [Vtilde_aw_temp, Vtilde_bk_temp, Vtilde_hvy_temp, Vtilde_mcd_temp, Vtilde_wdy_temp] = ...
            forwardsimB(P_tilde_mcd, P_tilde_other, T_pop, T_inc, dataB, Qnew(marketsubset,:));
    
        Vtilde_aw  = [Vtilde_aw; Vtilde_aw_temp]; % Stack values from each perturbed policy
        Vtilde_bk  = [Vtilde_bk; Vtilde_bk_temp];
        Vtilde_hvy = [Vtilde_hvy; Vtilde_hvy_temp];
        Vtilde_mcd = [Vtilde_mcd; Vtilde_mcd_temp];
        Vtilde_wdy = [Vtilde_wdy; Vtilde_wdy_temp];
    
        toc
    end

    V_tilde_mcd = [Vtilde_mcd]; % Stack across firms
    V_tilde_other = [Vtilde_aw; Vtilde_bk; Vtilde_hvy; Vtilde_wdy]; % Stack across firms

    V_star_mcd = [repmat(Vstar_mcd,Perturb,1)]; % Replicate & stack, for ease of comparison with V_tilde
    V_star_other = [repmat(Vstar_aw,Perturb,1);...
          repmat(Vstar_bk,Perturb,1);...
          repmat(Vstar_hvy,Perturb,1);...
          repmat(Vstar_wdy,Perturb,1)]; % Replicate & stack, for ease of comparison with V_tilde

    % Estimate Psi for each bootstrap subsample.
    options = optimset('Display','iter','TolFun',1e-12,'TolX',1e-8,'MaxIter',10000,'MaxFunEvals',10000);
    Psi0 = zeros(nparam,1);
    
    [Psi_mcd,fvalS_mcd] = fmincon('mindist',Psi0,[],[],[0,0,0,0,0,0,1,0,0],0,[],[],[],options,V_star_mcd,V_tilde_mcd);
    PsiB_mcd(:,b) = Psi_mcd;
    
    [Psi_other,fvalS_other] = fmincon('mindist',Psi0,[],[],[0,0,0,0,0,0,1,0,0],0,[],[],[],options,V_star_other,V_tilde_other);
    PsiB_other(:,b) = Psi_other;

end

% Creates table of second stage bootstrap confidence intervals.
columnLabels = {'Estimates','SE'};
rowLabels = {'High type ($\alpha _{1}$)', 'Own competition ($\alpha _{2}$)', 'Rival competition ($\alpha _{3}$)', 'Population ($\theta _{1}$)', 'Average income ($\theta _{2}$)', 'Entry sunk cost ($\kappa _{entry}$)', 'Exit sunk cost ($\kappa _{exit}$)', 'Low type ($\omega _{1}$)', 'Medium type ($\omega _{2}$)'};

seB_mcd = sqrt(var(PsiB_mcd'));   % Calculate the bootstrapped standard errors.
results_mcd = [estimates_mcd, seB_mcd'];
save('results_mcd.mat', 'results_mcd')

seB_other = sqrt(var(PsiB_other'));   % Calculate the bootstrapped standard errors.
results_other = [estimates_other, seB_other'];
save('results_other.mat', 'results_other')

matrix2latex(results_mcd, 'PsiB_bootstrap_am_se_mcd.tex', 'columnLabels', columnLabels, 'rowLabels', rowLabels, 'alignment', 'c', 'format', '%-6.6f', 'size', 'footnotesize');
matrix2latex(results_other, 'PsiB_bootstrap_am_se_other.tex', 'columnLabels', columnLabels, 'rowLabels', rowLabels, 'alignment', 'c', 'format', '%-6.6f', 'size', 'footnotesize');
