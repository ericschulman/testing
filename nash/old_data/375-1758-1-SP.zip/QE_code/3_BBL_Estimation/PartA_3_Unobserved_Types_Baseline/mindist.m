% Dynamic Spatial Oligopoly.                                    %
% By Mitsuru Igami and Nathan Yang.                             %
% Calculates the BBL minimum distance objective function.       %
% December 21, 2013.                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Q = mindist(thetaS,APIstar,APIperturb)

numperturb = 1000;
numcolumn = size(APIstar,2);

% Use the BBL linearization trick to save on computation time.
% Note: APIstar and APIperturb need only be constructed once for each
% search of the parameters.
Vstar = APIstar(:,1:(numcolumn-1))*thetaS + APIstar(:,numcolumn);                 % Simulated equilibrium values that are linear in structural parameters.
Vperturb = APIperturb(:,1:(numcolumn-1))*thetaS + APIperturb(:,numcolumn);        % Simulated perturbed values that are linear in structural parameters.

Q = 0;      % Initialize criterion.
nbind = 0;  % Number of binding constraints.

for j = 1:length(Vstar)
    if Vstar(j) < Vperturb(j)
        Q = Q + (Vstar(j) - Vperturb(j))^2;         % Penlalize parameters for which Vstar < Vperturb.
        nbind = nbind + 1;
    end
end
   
Q = Q/numperturb;           % Return criterion used for the minimum distance optimization.

end