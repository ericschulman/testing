% Dynamic Spatial Oligopoly.                                     %
% By Mitsuru Igami and Nathan Yang.                              %
% Get subsample of data for bootstrapping.                       %
% March 12, 2013.                                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function datasubsamp = datasubsamp(marketsubset,data)

years = 35;

if marketsubset(1) == 1    
    datasubsamp = data(1:years,:);
else 
    datasubsamp = data((marketsubset(1)-1)*years+1:marketsubset(1)*years,:);    
end

for market = marketsubset(2:length(marketsubset))
    % Parse out the data based on market index.
    if market == 1    
        dataS = data(1:years,:);
    else 
        dataS = data((market-1)*years+1:market*years,:);    
    end
    
    datasubsamp  = [datasubsamp;dataS];
end    