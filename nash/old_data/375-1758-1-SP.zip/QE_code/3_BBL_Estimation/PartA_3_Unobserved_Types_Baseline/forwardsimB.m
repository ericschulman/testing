% Cannibal Burger.                    %
% By Mitsuru Igami and Nathan Yang.   %
% Forward simulation                  %
% December 21, 2013.                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Given some policy function, returns its expected values 
% (or 10 value-function arguments before multiplication by Psi, to be precise)
% based on the average of 100 simulation paths over 35 years

function [weightV_aw, weightV_bk, weightV_hvy, weightV_mcd, weightV_wdy] = forwardsimB(P_mcd, P_other, T1, T2, data, q)

% Basic setting
beta = 0.90;             % Discount factor
NS = 100;                % Number of simulations
T = 35;                  % Number of years
M = 300;      % Number of markets (400?)
I = 5;                   % Number of players
narg = 10;               % Number of arguments in period profit (including epsilon)
Beta = ones(T,1);        % 36-year vector of discount factor
for t = 1:T
    Beta(t) = beta^(t-1);
end
numtypes = size(q,2);    % Number of unobserved market types. 

% Create random draws.
seed = 645456;           % Seed value for random draws
rng(seed);               % Set the seed
U1 = rand(NS,M,T);       % Draw shocks for population transition.
seed = 645457;           % Seed value for random draws
rng(seed);               % Set the seed
U2 = rand(NS,M,T);       % Draw shocks for income transition.   
seed = 645458;           % Seed value for random draws
rng(seed);               % Set the seed
U3 = rand(NS*T,I*3,M,T); % Draw shocks for structural IID error.
seed = 645459;           % Seed value for random draws
rng(seed);               % Set the seed
U4 = rand(NS,I,M,T);     % Draw shocks for the CCPs.

% Construct discretized variables (z = 0, 1, 2, or 3).
pop = data(:,24);           % Population.
inc = data(:,26);           % Income
pop25 = quantile(pop,0.25);   
inc25 = quantile(inc,0.25);  
pop50 = quantile(pop,0.5);  
inc50 = quantile(inc,0.5);  
pop75 = quantile(pop,0.75);   
inc75 = quantile(inc,0.75);   
o = ones(length(data),1);
data(:,31) = o.*0.*(pop <= pop25) + o.*1.*(pop > pop25 & pop <= pop50) + o.*2.*(pop > pop50 & pop <= pop75) + o.*3.*(pop > pop75);  
data(:,32) = o.*0.*(inc <= inc25) + o.*1.*(inc > inc25 & inc <= inc50) + o.*2.*(inc > inc50 & inc <= inc75) + o.*3.*(inc > inc75);  
  
% Matrix to store the output = expected values (9 value-function arguments)
V_aw = zeros(M,narg);   
V_bk = zeros(M,narg);        
V_hvy = zeros(M,narg);        
V_mcd = zeros(M,narg);        
V_wdy = zeros(M,narg);   

% Empty matrix to initialize the weighted output = expected values (9 value-function arguments)
weightV_aw = []; 
weightV_bk = [];
weightV_hvy = [];
weightV_mcd = [];
weightV_wdy = [];

% Outer loop: For each unobserved market type.
for s = 1:numtypes

    % Parse out the relevant columns of the CCP based on the unobserved market type.    
    
    % For McDonald's.
    if s == 1    
        Pweight_mcd = P_mcd(:,1:3);         % Type 1 market.
        Pweight_other = P_other(:,1:3);         % Type 1 market.
    elseif s == 2
        Pweight_mcd = P_mcd(:,4:6);         % Type 2 market.
        Pweight_other = P_other(:,4:6);         % Type 2 market.
    else    
        Pweight_mcd = P_mcd(:,7:9);         % Type 3 market.
        Pweight_other = P_other(:,7:9);         % Type 3 market.
    end
    
    % Construct market-specific Q matrix of weights to be multiplied to profits across each market.
    % Note: As many columns as there are arguments (narg = 10).
    Q = repmat(q(:,s),1,narg);

    % Loop 1: For each market
    for m = 1:M
        
        % Get data for each market & label variables
        data_m = data((m-1)*T+1:m*T,:);    
        m_N_aw = data_m(:,3);     % Number of outlets for A & W.
        m_N_bk = data_m(:,4);     % Number of outlets for Burger King.
        m_N_hvy = data_m(:,5);    % Number of outlets for Harvey's.
        m_N_mcd = data_m(:,6);    % Number of outlets for McDonald's.
        m_N_wdy = data_m(:,7);    % Number of outlets for Wendy's.
        m_pop = data_m(:,31);     % Discretized population.
        m_inc = data_m(:,32);     % Discretized income
        
        % Initialize
        Z = zeros(NS*T,2);          % Storage for exogenous state variables  
        N = zeros(NS*T,I);          % Storage for endogenous state variables  
        Pi_aw  = zeros(T,narg);     % Period profit for A & W (its 10 arguments)  
        Pi_bk  = zeros(T,narg);     % Period profit for Burger King (its 10 arguments)  
        Pi_hvy = zeros(T,narg);     % Period profit for Harvey's (its 10 arguments)  
        Pi_mcd = zeros(T,narg);     % Period profit for McDonald's (its 10 arguments)  
        Pi_wdy = zeros(T,narg);     % Period profit for Wendy's (its 10 arguments)  
    
        % Year-1 state variables come from data
        l = ones(NS,1);                         % [1000 x 1]
        Z0 = [m_pop(1), m_inc(1)];              % [1 x 2]
        Z0 = kron(Z0,l);                        % [1000 x 3]
        Z(1:NS,:) = Z0;                         % First 1000 rows of [35000 x 3]
    
        n0_aw  = 1*(m_N_aw(1) <= 3) * m_N_aw(1)  + 1*(m_N_aw(1) > 3) * 3;   % cap at 3
        n0_bk  = 1*(m_N_bk(1) <= 3) * m_N_bk(1)  + 1*(m_N_bk(1) > 3) * 3;
        n0_hvy = 1*(m_N_hvy(1)<= 3) * m_N_hvy(1) + 1*(m_N_hvy(1)> 3) * 3;
        n0_mcd = 1*(m_N_mcd(1)<= 3) * m_N_mcd(1) + 1*(m_N_mcd(1)> 3) * 3;
        n0_wdy = 1*(m_N_wdy(1)<= 3) * m_N_wdy(1) + 1*(m_N_wdy(1)> 3) * 3;
        N0 = [n0_aw(1), n0_bk(1), n0_hvy(1), n0_mcd(1), n0_wdy(1)];         % [1 x 5]
        N0 = kron(N0,l);                                                    % [1000 x 5]
        N(1:NS,:) = N0;                                                     % First 1000 rows of [35000 x 5]

        % Random draws of epsilon and nu
        %Shock_uniform = rand(NS*T, I*3);        % [35*1000, 5*3] = [35000 x 15]
        Shock_uniform = U3(:,:,m,t);
        Epsilons = -log(-log(Shock_uniform));   % Private cost shock epsilon (iid extreme value)
        
        % Loop 2: For each year (of 35 forward-simulated years)    
        for t = 1:T
        
            Zt = Z((t-1)*NS+1:t*NS,:);              % Today's exogenous state:  [NS x 3] = [1000 x 3]
            Nt = N((t-1)*NS+1:t*NS,:);              % Today's endogenous state: [NS x 5] = [1000 x 5]
        
            epsilon = Epsilons((t-1)*NS+1:t*NS,:);  % Today's epsilons: [NS x (I*3)] = [1000 x 15]
           
            % Today's exogenous state (z1,z2,z3)
            dz1 = Zt(:,1);
            dz2 = Zt(:,2);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % Transision of Z --> Z' %
            %%%%%%%%%%%%%%%%%%%%%%%%%%
        
            u1 = U1(:,m,t);            % Randomly drawn from uniform distribution for population transition.
            u2 = U2(:,m,t);            % Randomly drawn from uniform distribution for income transition. 
            
            zprime1 = (l.*1.*(dz1 == 0)).* ((0.*1.*(u1 <= T1(1,1))) + (1.*l.*1.*(u1 > T1(1,1)) & u1 <= T1(1,1)+T1(1,2)) + (2.*l.*1.*(u1 > T1(1,1)+T1(1,2)) & u1 <= T1(1,1)+T1(1,2)+T1(1,3)) + (3.*l.*1.*(u1 > T1(1,1)+T1(1,2)+T1(1,3)))) ... 
                    + (l.*1.*(dz1 == 1)).* ((0.*1.*(u1 <= T1(2,1))) + (1.*l.*1.*(u1 > T1(2,1)) & u1 <= T1(2,1)+T1(2,2)) + (2.*l.*1.*(u1 > T1(2,1)+T1(2,2)) & u1 <= T1(2,1)+T1(2,2)+T1(2,3)) + (3.*l.*1.*(u1 > T1(2,1)+T1(2,2)+T1(2,3)))) ...
                    + (l.*1.*(dz1 == 2)).* ((0.*1.*(u1 <= T1(3,1))) + (1.*l.*1.*(u1 > T1(3,1)) & u1 <= T1(3,1)+T1(3,2)) + (2.*l.*1.*(u1 > T1(3,1)+T1(3,2)) & u1 <= T1(3,1)+T1(3,2)+T1(3,3)) + (3.*l.*1.*(u1 > T1(3,1)+T1(3,2)+T1(3,3)))) ...
                    + (l.*1.*(dz1 == 3)).* ((0.*1.*(u1 <= T1(4,1))) + (1.*l.*1.*(u1 > T1(4,1)) & u1 <= T1(4,1)+T1(4,2)) + (2.*l.*1.*(u1 > T1(4,1)+T1(4,2)) & u1 <= T1(4,1)+T1(4,2)+T1(4,3)) + (3.*l.*1.*(u1 > T1(4,1)+T1(4,2)+T1(4,3))));
            
            zprime2 = (l.*1.*(dz2 == 0)).* ((0.*1.*(u2 <= T2(1,1))) + (1.*l.*1.*(u2 > T2(1,1)) & u2 <= T2(1,1)+T1(1,2)) + (2.*l.*1.*(u2 > T2(1,1)+T2(1,2)) & u2 <= T2(1,1)+T2(1,2)+T2(1,3)) + (3.*l.*1.*(u2 > T2(1,1)+T2(1,2)+T2(1,3)))) ... 
                    + (l.*1.*(dz2 == 1)).* ((0.*1.*(u2 <= T2(2,1))) + (1.*l.*1.*(u2 > T2(2,1)) & u2 <= T2(2,1)+T1(2,2)) + (2.*l.*1.*(u2 > T2(2,1)+T2(2,2)) & u2 <= T2(2,1)+T2(2,2)+T2(2,3)) + (3.*l.*1.*(u2 > T2(2,1)+T2(2,2)+T2(2,3)))) ...
                    + (l.*1.*(dz2 == 2)).* ((0.*1.*(u2 <= T2(3,1))) + (1.*l.*1.*(u2 > T2(3,1)) & u2 <= T2(3,1)+T1(3,2)) + (2.*l.*1.*(u2 > T2(3,1)+T2(3,2)) & u2 <= T2(3,1)+T2(3,2)+T2(3,3)) + (3.*l.*1.*(u2 > T2(3,1)+T2(3,2)+T2(3,3)))) ...
                    + (l.*1.*(dz2 == 3)).* ((0.*1.*(u2 <= T2(4,1))) + (1.*l.*1.*(u2 > T2(4,1)) & u2 <= T2(4,1)+T1(4,2)) + (2.*l.*1.*(u2 > T2(4,1)+T2(4,2)) & u2 <= T2(4,1)+T2(4,2)+T2(4,3)) + (3.*l.*1.*(u2 > T2(4,1)+T2(4,2)+T2(4,3))));
            
            zprime = [zprime1, zprime2];

            if t < T
                Z(t*NS+1:(t+1)*NS,:) = zprime;      % Record next-period Z, for all simulated draws.    
            end
        
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Defining Current State (N_it) %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
            % Number of own shops (in state space; capped at 3)
            ni_aw  = 1*(Nt(:,1) <= 3).*Nt(:,1) + 1*(Nt(:,1) > 3)*3;
            ni_bk  = 1*(Nt(:,2) <= 3).*Nt(:,2) + 1*(Nt(:,2) > 3)*3;
            ni_hvy = 1*(Nt(:,3) <= 3).*Nt(:,3) + 1*(Nt(:,3) > 3)*3;
            ni_mcd = 1*(Nt(:,4) <= 3).*Nt(:,4) + 1*(Nt(:,4) > 3)*3;
            ni_wdy = 1*(Nt(:,5) <= 3).*Nt(:,5) + 1*(Nt(:,5) > 3)*3;
               
            % Number of rival shops (in state space; capped at 3)
            nj_aw  = Nt(:,2) + Nt(:,3) + Nt(:,4) + Nt(:,5);
            nj_bk  = Nt(:,1) + Nt(:,3) + Nt(:,4) + Nt(:,5);
            nj_hvy = Nt(:,1) + Nt(:,2) + Nt(:,4) + Nt(:,5);
            nj_mcd = Nt(:,1) + Nt(:,2) + Nt(:,3) + Nt(:,5);
            nj_wdy = Nt(:,1) + Nt(:,2) + Nt(:,3) + Nt(:,4);

            nj_aw  = 1*(nj_aw  <= 3).*nj_aw  + 1*(nj_aw  > 3)*3;
            nj_bk  = 1*(nj_bk  <= 3).*nj_bk  + 1*(nj_bk  > 3)*3;
            nj_hvy = 1*(nj_hvy <= 3).*nj_hvy + 1*(nj_hvy > 3)*3;
            nj_mcd = 1*(nj_mcd <= 3).*nj_mcd + 1*(nj_mcd > 3)*3;
            nj_wdy = 1*(nj_wdy <= 3).*nj_wdy + 1*(nj_wdy > 3)*3;
        
            x_aw  = [ni_aw , nj_aw , dz1, dz2];    % [1000 x 5]
            x_bk  = [ni_bk , nj_bk , dz1, dz2];   
            x_hvy = [ni_hvy, nj_hvy, dz1, dz2];
            x_mcd = [ni_mcd, nj_mcd, dz1, dz2];
            x_wdy = [ni_wdy, nj_wdy, dz1, dz2];
        
            % Market type indicator.
            type2 = 1*(s == 2).*ones(length(ni_aw),1);
            type3 = 1*(s == 3).*ones(length(ni_aw),1);
        
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Simulate Actions according to Policy Function %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
            % Get state ID #s corresponding to the simulated states in x_all: [5000x5] --> [5000x1]
            stateID_aw = (4*4*4)*x_aw(:,1) + (4*4)*x_aw(:,2) + 4*(x_aw(:,3)) + (x_aw(:,4) + ones(NS,1));
            stateID_bk = (4*4*4)*x_bk(:,1) + (4*4)*x_bk(:,2) + 4*(x_bk(:,3)) + (x_bk(:,4) + ones(NS,1));
            stateID_hvy = (4*4*4)*x_hvy(:,1) + (4*4)*x_hvy(:,2) + 4*(x_hvy(:,3)) + (x_hvy(:,4) + ones(NS,1));
            stateID_mcd = (4*4*4)*x_mcd(:,1) + (4*4)*x_mcd(:,2) + 4*(x_mcd(:,3)) + (x_mcd(:,4) + ones(NS,1));
            stateID_wdy = (4*4*4)*x_wdy(:,1) + (4*4)*x_wdy(:,2) + 4*(x_wdy(:,3)) + (x_wdy(:,4) + ones(NS,1));

            % Get choice probs corresponding to the state ID#s, from the policy function. [5000 x 3]
            P_tilde_aw = Pweight_other(stateID_aw,:);
            P_tilde_bk = Pweight_other(stateID_bk,:);
            P_tilde_hvy = Pweight_other(stateID_hvy,:);
            P_tilde_mcd = Pweight_mcd(stateID_mcd,:);
            P_tilde_wdy = Pweight_other(stateID_wdy,:);
       
            %U = rand(length(P_tilde_aw),I);     % Simulate the discrete choice by using random U(0,1) draws. [5000 x 1]
            U = U4(:,:,m,t);
            
            a_aw = -1*1*(U(:,1) <= P_tilde_aw(:,1)) + 1*(U(:,1) > (1 - P_tilde_aw(:,3)));
            a_bk = -1*1*(U(:,2) <= P_tilde_bk(:,1)) + 1*(U(:,2) > (1 - P_tilde_bk(:,3)));
            a_hvy = -1*1*(U(:,3) <= P_tilde_hvy(:,1)) + 1*(U(:,3) > (1 - P_tilde_hvy(:,3)));
            a_mcd = -1*1*(U(:,4) <= P_tilde_mcd(:,1)) + 1*(U(:,4) > (1 - P_tilde_mcd(:,3)));
            a_wdy = -1*1*(U(:,5) <= P_tilde_wdy(:,1)) + 1*(U(:,5) > (1 - P_tilde_wdy(:,3)));

            A = [a_aw, a_bk, a_hvy, a_mcd, a_wdy];
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%
            % Transision of N --> N' %
            %%%%%%%%%%%%%%%%%%%%%%%%%%
               
            % Calculate & save tomorrow's number of shops
            N2raw = Nt + A;    % N' = N + A (in raw numbers of stores) [1000 x 5]
            N2 = N2raw.*(1*(N2raw > 0 & N2raw <= 3)) + 0.*(1*(N2raw < 0)) + 3.*(1*(N2raw > 3));
            if t < T
                N(t*NS+1:(t+1)*NS, :) = N2;     % The t-th [1000 x 5] of [35000 x 5]
            end
               
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Calculate Period Profit %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
        
            % The "actual" profit shocks (i.e., the epsilon that is associated with the chosen action): [1000 x 1] per (i,t)
            euler = 0.5772*ones(NS,1);
            P_tilde_aw_nonzero = P_tilde_aw  .* (P_tilde_aw  > .0001) + .0001 .* (P_tilde_aw  <= .0001);   % Avoid NaN by limiting prob >= .0001
            P_tilde_bk_nonzero = P_tilde_bk  .* (P_tilde_bk  > .0001) + .0001 .* (P_tilde_bk  <= .0001);   % Avoid NaN by limiting prob >= .0001
            P_tilde_hvy_nonzero = P_tilde_hvy.* (P_tilde_hvy > .0001) + .0001 .* (P_tilde_hvy <= .0001);   % Avoid NaN by limiting prob >= .0001
            P_tilde_mcd_nonzero = P_tilde_mcd.* (P_tilde_mcd > .0001) + .0001 .* (P_tilde_mcd <= .0001);   % Avoid NaN by limiting prob >= .0001
            P_tilde_wdy_nonzero = P_tilde_wdy.* (P_tilde_wdy > .0001) + .0001 .* (P_tilde_wdy <= .0001);   % Avoid NaN by limiting prob >= .0001
            ep_aw = [euler - log(P_tilde_aw_nonzero(:,1)), euler - log(P_tilde_aw_nonzero(:,2)), euler - log(P_tilde_aw_nonzero(:,3))];
            ep_bk = [euler - log(P_tilde_bk_nonzero(:,1)), euler - log(P_tilde_bk_nonzero(:,2)), euler - log(P_tilde_bk_nonzero(:,3))];
            ep_hvy = [euler - log(P_tilde_hvy_nonzero(:,1)), euler - log(P_tilde_hvy_nonzero(:,2)), euler - log(P_tilde_hvy_nonzero(:,3))];
            ep_mcd = [euler - log(P_tilde_mcd_nonzero(:,1)), euler - log(P_tilde_mcd_nonzero(:,2)), euler - log(P_tilde_mcd_nonzero(:,3))];
            ep_wdy = [euler - log(P_tilde_wdy_nonzero(:,1)), euler - log(P_tilde_wdy_nonzero(:,2)), euler - log(P_tilde_wdy_nonzero(:,3))];
            epsilon = [ep_aw, ep_bk, ep_hvy, ep_mcd, ep_wdy];
            e_aw  = (1*(a_aw < 0)) .* epsilon(:,1) + (1*(a_aw==0)) .* epsilon(:,2) + (1*(a_aw > 0)) .* epsilon(:,3);
            e_bk  = (1*(a_bk < 0)) .* epsilon(:,4) + (1*(a_bk==0)) .* epsilon(:,5) + (1*(a_bk > 0)) .* epsilon(:,6);
            e_hvy = (1*(a_hvy < 0)).* epsilon(:,7) + (1*(a_hvy==0)).* epsilon(:,8) + (1*(a_hvy > 0)).* epsilon(:,9);
            e_mcd = (1*(a_mcd < 0)).* epsilon(:,10) + (1*(a_mcd==0)).* epsilon(:,11) + (1*(a_mcd > 0)).*epsilon(:,12);
            e_wdy = (1*(a_wdy < 0)).* epsilon(:,13) + (1*(a_wdy==0)).* epsilon(:,14) + (1*(a_wdy > 0)).*epsilon(:,15);
           
            % 10 arguments of profit = (const, Ni, Nj, dz1, dz2, kappa(+), kappa(-), epsilon): [1000 x 1] per (i,t)
            pi_aw = [ni_aw, ni_aw.*ni_aw, ni_aw.*nj_aw, ni_aw.*dz1, ni_aw.*dz2, -1*(a_aw>0), -1*(a_aw<0), type2.*ni_aw, type3.*ni_aw, e_aw];
            pi_bk = [ni_bk, ni_bk.*ni_bk, ni_bk.*nj_bk, ni_bk.*dz1, ni_bk.*dz2, -1*(a_bk>0), -1*(a_bk<0), type2.*ni_bk, type3.*ni_bk, e_bk];
            pi_hvy = [ni_hvy, ni_hvy.*ni_hvy, ni_hvy.*nj_hvy, ni_hvy.*dz1, ni_hvy.*dz2, -1*(a_hvy>0), -1*(a_hvy<0), type2.*ni_hvy, type3.*ni_hvy, e_hvy];
            pi_mcd = [ni_mcd, ni_mcd.*ni_mcd, ni_mcd.*nj_mcd, ni_mcd.*dz1, ni_mcd.*dz2, -1*(a_mcd>0), -1*(a_mcd<0), type2.*ni_mcd, type3.*ni_mcd, e_mcd];
            pi_wdy = [ni_wdy, ni_wdy.*ni_wdy, ni_wdy.*nj_wdy, ni_wdy.*dz1, ni_wdy.*dz2, -1*(a_wdy>0), -1*(a_wdy<0), type2.*ni_wdy, type3.*ni_wdy, e_wdy];

            % Expected profits: Take average over 1000 simulations
            avgpi_aw  = (1/NS) * sum(pi_aw, 1); % Collapse: [1000 x 1] --> [1 x 1]
            avgpi_bk  = (1/NS) * sum(pi_bk, 1);
            avgpi_hvy = (1/NS) * sum(pi_hvy, 1);
            avgpi_mcd = (1/NS) * sum(pi_mcd, 1);
            avgpi_wdy = (1/NS) * sum(pi_wdy, 1);
        
            % Record today's average profits (9 arguments)
            Pi_aw(t,:)  = avgpi_aw; % The t-th [1 x 9] of [35 x 9]
            Pi_bk(t,:)  = avgpi_bk;
            Pi_hvy(t,:) = avgpi_hvy;
            Pi_mcd(t,:) = avgpi_mcd;
            Pi_wdy(t,:) = avgpi_wdy;
 
        end % End of Loop 2 (t = 1:T)
    
        % Expected value = Sum of discounted profits
        V_aw(m,:) = Beta' * Pi_aw;  % The m-th [1 x 9] of [400 x 9] = [1 x 35] * [35 x 9]
        V_bk(m,:) = Beta' * Pi_bk;
        V_hvy(m,:) = Beta' * Pi_hvy;
        V_mcd(m,:) = Beta' * Pi_mcd;
        V_wdy(m,:) = Beta' * Pi_wdy;

    %toc;
    end % End of Loop 1 (m = 1:z)

% Stack the Q-weighted values as each market type is iterated. 
weightV_aw = [weightV_aw; Q.*V_aw];
weightV_bk = [weightV_bk; Q.*V_bk];
weightV_hvy = [weightV_hvy; Q.*V_hvy];
weightV_mcd = [weightV_mcd; Q.*V_mcd];
weightV_wdy = [weightV_wdy; Q.*V_wdy];

end

end