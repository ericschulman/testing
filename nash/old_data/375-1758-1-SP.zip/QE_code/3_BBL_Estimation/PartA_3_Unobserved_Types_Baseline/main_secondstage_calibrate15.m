% Cannibal Burger          .                         %
% By Mitsuru Igami and Nathan Yang.                  %
% Main AM-BBL program for second stage estimation.   %
% January 16, 2014.                                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

% Load the data.
load canadafastfood;

% Rename 1st-stage AM estimates as the optimal policy
load P_mcd_new;                             % 1st-stage q-weighted policy function estimates for McDonald's.
load P_other_new;                           % 1st-stage q-weighted policy function estimates for others.
% Note: P_[] = P(state,action,market type)
%            = [Pr(a = -1|Low), Pr(a = 0|Low), Pr(a = +1|Low), ...
%               Pr(a = -1|Mid), Pr(a = 0|Mid), Pr(a = +1|Mid), ...
%               Pr(a = -1|High), Pr(a = 0|High), Pr(a = +1|High)]
P_mcd = [0.5*P_other_new(:,1,3), P_mcd_new(:,2,1), P_mcd_new(:,3,1), 0.5*P_other_new(:,1,2), P_mcd_new(:,2,2), P_mcd_new(:,3,2),0.5*P_other_new(:,1,1), P_mcd_new(:,2,3), P_mcd_new(:,3,3)];
P_other = [P_other_new(:,:,1), P_other_new(:,:,2), P_other_new(:,:,3)];
P_star_mcd = P_mcd;                     % Policy function [256 x 3]
P_star_other = P_other;                 % Policy function [256 x 3]

% Q matrix of posterior probabilities.
load Q_new;
Qnew = Q_new;

% Load the transition matrices for population, income, and property value.
load T_pop
load T_inc

% Calculate expected values (before multiplied by Psi) from observed policy
Player = 5;         % Number of (symmetric) players
T = 35;             % Number of time periods (don't use year 2005 data)
MT = length(data);  % Number of observations.
M = MT/T;           % Number of markets
narg = 10;          % Number of arguments in profit & value functions

fprintf('\n Calculating the expected values, of sticking to the observed policy');
fprintf('\n ');
tic
 
[Vstar_aw, Vstar_bk, Vstar_hvy, Vstar_mcd, Vstar_wdy] = ...
    forwardsim(P_star_mcd, P_star_other, T_pop, T_inc, data, Qnew); % Find expected values by simulation
toc

% Calculate expected values (before multiplied by Psi) from perturbed policies
Perturb = 1000;     % Number of perturbations, 1000

seed = 645477;      % Seed value for random draws
rng(seed);          % Set the seed
perturb1 = normrnd(0, .02, length(P_mcd), Perturb, 2, 3);  % Noise to prob(-).
perturb3 = normrnd(0, .02, length(P_mcd), Perturb, 2, 3);  % Noise to prob(+).
perturb2 = -(perturb1 + perturb3);                         % Noise to prob(0).

Vtilde_aw = []; Vtilde_bk = []; Vtilde_hvy = []; Vtilde_mcd = []; Vtilde_wdy = []; % Initialize

for per = 1:Perturb     % For each perturbed policy

    fprintf('\n Calculating the expected values, of using alternative policy # %2.0f:', per);
    tic
    
    noise_mcd = [perturb1(:,per,1,1), perturb2(:,per,1,1), perturb3(:,per,1,1), perturb1(:,per,1,2), perturb2(:,per,1,2), perturb3(:,per,1,2), perturb1(:,per,1,3), perturb2(:,per,1,3), perturb3(:,per,1,3)];
    noise_other = [perturb1(:,per,2,1), perturb2(:,per,2,1), perturb3(:,per,2,1), perturb1(:,per,2,2), perturb2(:,per,2,2), perturb3(:,per,2,2), perturb1(:,per,2,3), perturb2(:,per,2,3), perturb3(:,per,2,3)];

    P_tilde_mcd = P_star_mcd + noise_mcd;         % Perturbed McDonald's policy = optimal policy + noise
    P_tilde_other = P_star_other + noise_other;   % Perturbed others policy = optimal policy + noise

    [Vtilde_aw_temp, Vtilde_bk_temp, Vtilde_hvy_temp, Vtilde_mcd_temp, Vtilde_wdy_temp] = ...
        forwardsim(P_tilde_mcd, P_tilde_other, T_pop, T_inc, data, Qnew);
    
    Vtilde_aw  = [Vtilde_aw; Vtilde_aw_temp]; % Stack values from each perturbed policy
    Vtilde_bk  = [Vtilde_bk; Vtilde_bk_temp];
    Vtilde_hvy = [Vtilde_hvy; Vtilde_hvy_temp];
    Vtilde_mcd = [Vtilde_mcd; Vtilde_mcd_temp];
    Vtilde_wdy = [Vtilde_wdy; Vtilde_wdy_temp];
    
    toc
end

%save secondstage_interim_am.mat;  % Save all of the pre-minimization results.


%% Estimate structural parameters

% Optimization settings and initialization.
options = optimset('Display','iter','TolFun',1e-12,'TolX',1e-8,'MaxIter',10000,'MaxFunEvals',10000);
numparam = narg - 1;
Psi0 = zeros(numparam,1);
norm = 0;       % Normalization of exit cost. 

% 2 separate profit functions (by firm type).
V_tilde_mcd = [Vtilde_mcd]; % Stack across firms
V_tilde_other = [Vtilde_aw; Vtilde_bk; Vtilde_hvy; Vtilde_wdy]; % Stack across firms

V_star_mcd = [repmat(Vstar_mcd,Perturb,1)]; % Replicate & stack, for ease of comparison with V_tilde
V_star_other = [repmat(Vstar_aw,Perturb,1);...
          repmat(Vstar_bk,Perturb,1);...
          repmat(Vstar_hvy,Perturb,1);...
          repmat(Vstar_wdy,Perturb,1)]; % Replicate & stack, for ease of comparison with V_tilde
      
% Estimate parameters under different normalizations of scrap value.
[Psi_kappa0_mcd,fvalS_kappa0_mcd] = fmincon('mindist',Psi0,[],[],[0,0,0,0,0,0,1,0,0],norm,[],[],[],options,V_star_mcd,V_tilde_mcd);
save('Psi_kappa0_mcd_cal15.mat', 'Psi_kappa0_mcd')

[Psi_kappa0_other,fvalS_kappa0_other] = fmincon('mindist',Psi0,[],[],[0,0,0,0,0,0,1,0,0],norm,[],[],[],options,V_star_other,V_tilde_other);
save('Psi_kappa0_other_cal15.mat', 'Psi_kappa0_other')
