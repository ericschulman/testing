% Cannibal Burger.                              %
% By Mitsuru Igami and Nathan Yang.             %
% Compare CCPs across different models          %
% March 12, 2013.                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Main setup.

% Load the data and states.
load canadafastfood_inc2005
load gamestates
load T_inc
load T_pop
load Q_new

% Generate Q weighting.
Q = [];
for m = 1:400
   Q = [Q; repmat(Q_new(m,3),35,1)]; 
end

%% Simulate data.

% Generate forward simulated number of outlets using CCPs from MPE.
load P_mcd_mpe
load P_other_mpe

N_mpe = forwardsim(P_mcd_mpe, P_other_mpe, T_pop, T_inc, data);

% Generate forward simulated number of outlets using CCPs from MPE with no cannibalization.
load P_mcd_nocannibal
load P_other_nocannibal

N_nocannibal = forwardsim(P_mcd_mpe, P_other_mpe, T_pop, T_inc, data);

% Generate forward simulated number of outlets using CCPs from robot counterfactual.
load P_mcd_robot
load P_mcd_cf
load P_other_robot
load P_other_am

N_robot = forwardsim(P_mcd_cf, P_other_new(:,:,3), T_pop, T_inc, data);

%% Simulate average trajectories for McDonald's.

% Main settings for computing the average trajectories.
numyears = 36;
nummarkets = 400;
T = [1970:1:2005]';
time = data(:,2);

% Get McDonald's trajectories.
Nt = data(:,3:7);
N_actual_mcd = Nt(:,4);
N_mpe_mcd = N_mpe(:,4);
N_robot_mcd = N_robot(:,4);
N_nocannibal_mcd = N_nocannibal(:,4);

N_avgactual_mcd = zeros(numyears,1);
N_avgmpe_mcd = zeros(numyears,1);
N_avgrobot_mcd = zeros(numyears,1);
N_avgnocannibal_mcd = zeros(numyears,1);

for t = 1:numyears
    year = 1970 + t - 1;
    N_avgactual_mcd(t) = (1/nummarkets)*sum((1.*(time == year)).*N_actual_mcd);
    N_avgmpe_mcd(t) = (1/nummarkets)*sum((1.*(time == year)).*N_mpe_mcd);
    N_avgrobot_mcd(t) = (1/nummarkets)*sum((1.*(time == year)).*N_robot_mcd);
    N_avgnocannibal_mcd(t) = (1/nummarkets)*sum((1.*(time == year)).*N_nocannibal_mcd);
end    

results_counterfactual = [T, N_avgactual_mcd, N_avgmpe_mcd, N_avgrobot_mcd, N_avgnocannibal_mcd];
save('results_counterfactual.mat', 'results_counterfactual')
csvwrite('results_counterfactual.csv',results_counterfactual);
