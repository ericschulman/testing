% Dynamic Spatial Oligopoly.                                                    %
% By Mitsuru Igami and Nathan Yang.                                             %
% Main program for conducting "McDonald's vs Robots" counterfactual.            %
% February 11, 2014.                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Comment (Feb. 11, 2014): The code now uses counterfactual CCP_mcd(Exit) = 0 for all states.
% Without this normalization, there were states in which counterfactual exit probabilities
% are found to be close to 1, which deviates too much from the true data patterns (i.e., McDonald's does not exit).
% I have preserved the code that does not constrain CCP_mcd(Exit) as comments in "Archives >>> 2014-02-02".
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Load data, states, and parameters.

% Load the data.
load canadafastfood

% Load the game states.
load gamestates

% Load the CCPs from AM first stage estimation.
load P_mcd_new;                             % 1st-stage q-weighted policy function estimates for McDonald's.
load P_other_new;                           % 1st-stage q-weighted policy function estimates for others.
P_mcd_eq = P_mcd_new(:,:,3);
save('P_mcd_eq.mat', 'P_mcd_eq')            % Store the equilibrium probabilities for McDonald's.

% Load probabilities for number of competitors.
load P_other_70
load P_other_80
load P_other_90
load P_other_00

P_other_70 = [P_other_70(:,1)./P_other_70(:,5), P_other_70(:,2)./P_other_70(:,5), P_other_70(:,3)./P_other_70(:,5), P_other_70(:,4)./P_other_70(:,5)];
P_other_80 = [P_other_80(:,1)./P_other_80(:,5), P_other_80(:,2)./P_other_80(:,5), P_other_80(:,3)./P_other_80(:,5), P_other_80(:,4)./P_other_80(:,5)];
P_other_90 = [P_other_90(:,1)./P_other_90(:,5), P_other_90(:,2)./P_other_90(:,5), P_other_90(:,3)./P_other_90(:,5), P_other_90(:,4)./P_other_90(:,5)];
P_other_00 = [P_other_00(:,1)./P_other_00(:,5), P_other_00(:,2)./P_other_00(:,5), P_other_00(:,3)./P_other_00(:,5), P_other_00(:,4)./P_other_00(:,5)];

P_other = [];

P_other(:,:,1) = P_other_70;
P_other(:,:,2) = P_other_80;
P_other(:,:,3) = P_other_90;
P_other(:,:,4) = P_other_00;

% Load the transition matrices for population and income.
load T_pop
load T_inc

% Load the estimated parameters from BBL second stage estimation.
load Psi_kappa0_mcd_cal15
load Psi_kappa0_other_cal15
theta_mcd = Psi_kappa0_mcd;
theta_other = Psi_kappa0_other;

%% Obtain counterfactual CCP.

% Initializations for counterfactual CCP search.
numstates = length(states);             % Number of states.
numactions = 3;                         % Number of actions.
numparm = 5;                            % Number of parameters in McDonald's approximated counterfactual CCP.
gamma0 = 0.5*ones(numparm,1);           % Initialize parameters.
avgstate = calculate_avg(data);         % Initial states.

% Set the constraints.
% Upper bound for entry fitted parameters respectively (i.e., x_mcd*gamma_enter).  
UB = -4.9;            
A = [1, 1, 1, 1, 1];  

% Search for counterfactual CCP.
options = optimset('Display','iter','TolFun',1e-12,'TolX',1e-12,'MaxIter',15000,'MaxFunEvals',15000);
gamma_mcd_cf = fmincon('forwardsim_parametric',gamma0,A,UB,[],[],[],[],[],options,P_other,T_pop,T_inc,theta_mcd,theta_other,avgstate);
save('gamma_mcd_cf.mat', 'gamma_mcd_cf')

%% Construct CCP using parameters obtained from counterfactual simulations.

% Parse out the states.
ni_mcd = states(:,1);
nj_mcd = states(:,2);
dz1 = states(:,3);
dz2 = states(:,4);
x_mcd = [ones(length(states),1), ni_mcd, nj_mcd, dz1, dz2];

% Calculate counterfactual CCPs.
gamma = gamma_mcd_cf;
Penter_mcd = exp(x_mcd*gamma)./(ones(numstates,1)+exp(x_mcd*gamma));
Pnochange_mcd = ones(numstates,1) - Penter_mcd;
Pexit_mcd = zeros(length(states),1);
P_mcd_cf = [Pexit_mcd, Pnochange_mcd, Penter_mcd];
save('P_mcd_cf.mat', 'P_mcd_cf')    % Store the counterfactual probabilities.
