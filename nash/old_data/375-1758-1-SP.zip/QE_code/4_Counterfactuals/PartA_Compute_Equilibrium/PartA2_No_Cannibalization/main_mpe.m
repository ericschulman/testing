% Dynamic Spatial Oligopoly.                                                    %
% By Mitsuru Igami and Nathan Yang.                                             %
% Main program for conducting "McDonald's vs Robots" counterfactual.            %
% February 11, 2014.                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Load data, states, and parameters.

% Load the data.
load canadafastfood

% Load the game states.
load gamestates

% Load the CCPs from AM first stage estimation.
load P_mcd_new;                             % 1st-stage q-weighted policy function estimates for McDonald's.
load P_other_new;                           % 1st-stage q-weighted policy function estimates for others.
P_mcd_eq = P_mcd_new(:,:,3);
save('P_mcd_eq.mat', 'P_mcd_eq')            % Store the equilibrium probabilities for McDonald's.
P_other_eq = P_other_new(:,:,3);
save('P_other_eq.mat', 'P_other_eq')        % Store the equilibrium probabilities for others.

% Load the transition matrices for population and income.
load T_pop
load T_inc

% Load the estimated parameters from BBL second stage estimation.
load Psi_kappa0_mcd_cal15
load Psi_kappa0_other_cal15
theta_mcd = Psi_kappa0_mcd;
theta_other = Psi_kappa0_other;
theta_mcd(2) = theta_mcd(3);

%% Obtain MPE for other chains.

% Initializations for MPE search.
numstates = length(states);                         % Number of states.
numactions = 3;                                     % Number of actions.
numparm = 7;                                        % Number of parameters in McDonald's approximated counterfactual CCP.
P_mcd_init = P_mcd_new(:,:,3);                      % Keep CCP for others fixed.
P_other_init = P_other_new(:,:,3);                  % Keep CCP for others fixed.
gamma0_other = 0.5*ones(numparm*(numactions-1),1);      % Initialize parameters.
gamma0_mcd = 0.5*ones(numparm,1);                       % Initialize parameters.
avgstate = calculate_avg(data);                     % Initial states.
options = optimset('Display','iter','TolFun',1e-12,'TolX',1e-12,'MaxIter',15000,'MaxFunEvals',15000);
crit = 10;

% Set the constraints.
% Upper bound for entry fitted parameters respectively.  
Nimax = 0.4;
Njmax = 2.3;
UB_other = [-8, -8];         
UB_mcd = -5;           
A_other = [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0; ...
           0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1];  
A_mcd = [1, 1, 1, 1, 1, 1, 1];
        
% Parse out the states.
ni_other = states(:,1);
nj_other = states(:,2);
dz1 = states(:,3);
dz2 = states(:,4);
x_other = [ones(length(states),1), ni_other, nj_other, dz1, dz2, ni_other.^2, nj_other.^2];

ni_mcd = states(:,1);
nj_mcd = states(:,2);
dz1 = states(:,3);
dz2 = states(:,4);
x_mcd = [ones(length(states),1), ni_mcd, nj_mcd, dz1, dz2, ni_mcd.^2, nj_mcd.^2];

% Iterate to find MPE.
while crit > 10e-8

    % Search for equilibrium CCP for others.
    gamma_other_mpe = fmincon('forwardsim_other',gamma0_other,A_other,UB_other,[],[],[],[],[],options,P_mcd_init,T_pop,T_inc,theta_mcd,theta_other,avgstate);
    gamma_other = reshape(gamma_other_mpe,numparm,numactions-1);
    Pexit_other = exp(x_other*gamma_other(:,1))./(ones(numstates,1)+exp(x_other*gamma_other(:,1))+exp(x_other*gamma_other(:,2)));
    Penter_other = exp(x_other*gamma_other(:,2))./(ones(numstates,1)+exp(x_other*gamma_other(:,1))+exp(x_other*gamma_other(:,2)));
    Pnochange_other = ones(numstates,1) - Pexit_other - Penter_other;
    P_other_mpe = [Pexit_other, Pnochange_other, Penter_other];

    % Search for counterfactual CCP.
    gamma_mcd_mpe = fmincon('forwardsim_mcd',gamma0_mcd,A_mcd,UB_mcd,[],[],[],[],[],options,P_other_mpe,T_pop,T_inc,theta_mcd,theta_other,avgstate);
    gamma = gamma_mcd_mpe;
    Penter_mcd = exp(x_mcd*gamma)./(ones(numstates,1)+exp(x_mcd*gamma));
    Pnochange_mcd = ones(numstates,1) - Penter_mcd;
    Pexit_mcd = zeros(length(states),1);
    P_mcd_mpe = [Pexit_mcd, Pnochange_mcd, Penter_mcd];
    
    crit = norm(P_mcd_mpe - P_mcd_init) + norm(P_other_mpe - P_other_init)         % Stopping condition.
    
    P_other_init = P_other_mpe;         % Replace with new MPE.
    P_mcd_init = P_mcd_mpe;             % Replace with new MPE.

end

save('P_mcd_nocannibal.mat', 'P_mcd_mpe')        % Store the MPE probabilities for McDonald's.
save('P_other_nocannibal.mat', 'P_other_mpe')    % Store the MPE probabilities for others.

%% Evaluate model fit.

P_mcd = [P_mcd_mpe(:,3), P_mcd_eq(:,3)];        
P_other = [P_other_mpe(:,3), P_other_eq(:,3)];  

mean(P_mcd)             % Compare entry probabilities (MPE versus AM first stage).
mean(P_other)           % Compare entry probabilities (MPE versus AM first stage).

