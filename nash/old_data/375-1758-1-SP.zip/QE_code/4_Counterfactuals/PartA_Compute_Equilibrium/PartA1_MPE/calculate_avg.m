% Dynamic Spatial Oligopoly.                                                    %
% By Mitsuru Igami and Nathan Yang.                                             %
% Calculate average/mean state using data.                                      %
% February 1, 2014.                                                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function avgstate = calculate_avg(data)

% Labeling
MT = size(data,1);          % Size of the dataset (M x T = 400 x 35 = 14000).
clusterid = data(:,1);      % Unique market ID.
year = data(:,2);           % Year.
N_aw = data(:,3);           % Number of A & W outlets (in data).
N_bk = data(:,4);           % Number of Burger King outlets (in data).
N_hvy = data(:,5);          % Number of Harvey's outlets (in data).
N_mcd = data(:,6);          % Number of McDonald's outlets (in data).
N_wdy = data(:,7);          % Number of Wendy's outlets (in data).
lagN_aw = data(:,8);        % Lagged number of outlets.
lagN_bk = data(:,9);        
lagN_hvy = data(:,10);      
lagN_mcd = data(:,11);      
lagN_wdy = data(:,12);      
fwdN_aw = data(:,13);       % Forward (next period) number of outlets.
fwdN_bk = data(:,14);       
fwdN_hvy = data(:,15);      
fwdN_mcd = data(:,16);      
fwdN_wdy = data(:,17);      
a_aw = data(:,18);          % Action (change in number of outlets) for A & W.
a_bk = data(:,19);          % Action (change in number of outlets) for Burger King.
a_hvy = data(:,20);         % Action (change in number of outlets) for Harvey's.    
a_mcd = data(:,21);         % Action (change in number of outlets) for McDonald's.
a_wdy = data(:,22);         % Action (change in number of outlets) for Wendy's.
fsaid = data(:,23);         % FSA ID.
pop = data(:,24);           % Population.
inc = data(:,26);           % Income
val = data(:,25);           % Residential property value
cityid = data(:,27);        % City id (?).
fpop = data(:,28);          % Population at (t+1)
finc = data(:,29);          % Income at (t+1)
fval = data(:,30);          % Residential property value at (t+1)
mktfe = data(:,31);         % Market fixed effect estimates (from 130913_alaToivanenWaterson3_Fixedeffect3quantile.csv/dta)
tertile = data(:,32);       % Market type initial guess (from 130913_alaToivanenWaterson3_Fixedeffect3quantile.csv/dta)

% Number of own shops (in state space; capped at 3), from the perspective of each firm
Ni_aw = 1*(N_aw <= 3).*N_aw + 1*(N_aw > 3)*3;
Ni_bk = 1*(N_bk <= 3).*N_bk + 1*(N_bk > 3)*3;
Ni_hvy = 1*(N_hvy <= 3).*N_hvy + 1*(N_hvy > 3)*3;
Ni_mcd = 1*(N_mcd <= 3).*N_mcd + 1*(N_mcd > 3)*3;
Ni_wdy = 1*(N_wdy <= 3).*N_wdy + 1*(N_wdy > 3)*3;

% Number of rival shops (in state space; capped at 3), from the perspective of each firm
Nj_aw = N_bk + N_hvy + N_mcd + N_wdy;
Nj_bk = N_aw + N_hvy + N_mcd + N_wdy;
Nj_hvy = N_aw + N_bk + N_mcd + N_wdy;
Nj_mcd = N_aw + N_bk + N_hvy + N_wdy;
Nj_wdy = N_aw + N_bk + N_hvy + N_mcd;

Nj_aw = 1*(Nj_aw <= 3).*Nj_aw + 1*(Nj_aw > 3)*3;     
Nj_bk = 1*(Nj_bk <= 3).*Nj_bk + 1*(Nj_bk > 3)*3;
Nj_hvy = 1*(Nj_hvy <= 3).*Nj_hvy + 1*(Nj_hvy > 3)*3;
Nj_mcd = 1*(Nj_mcd <= 3).*Nj_mcd + 1*(Nj_mcd > 3)*3;
Nj_wdy = 1*(Nj_wdy <= 3).*Nj_wdy + 1*(Nj_wdy > 3)*3;

% Obtain 4 quantiles for main market characteristics.
pop25 = quantile(pop,0.25);   
inc25 = quantile(inc,0.25);  
pop50 = quantile(pop,0.5);  
inc50 = quantile(inc,0.5);  
pop75 = quantile(pop,0.75);   
inc75 = quantile(inc,0.75);   

o = ones(length(data),1);
disc_pop = o.*0.*(pop <= pop25) + o.*1.*(pop > pop25 & pop <= pop50) + o.*2.*(pop > pop50 & pop <= pop75) + o.*3.*(pop > pop75);  
disc_inc = o.*0.*(inc <= inc25) + o.*1.*(inc > inc25 & inc <= inc50) + o.*2.*(inc > inc50 & inc <= inc75) + o.*3.*(inc > inc75);  
disc_fpop = o.*0.*(fpop <= pop25) + o.*1.*(fpop > pop25 & fpop <= pop50) + o.*2.*(fpop > pop50 & fpop <= pop75) + o.*3.*(fpop > pop75);  
disc_finc = o.*0.*(finc <= inc25) + o.*1.*(finc > inc25 & finc <= inc50) + o.*2.*(finc > inc50 & finc <= inc75) + o.*3.*(finc > inc75);  

% Define state variables for each firm
RHS_aw = [Ni_aw, Nj_aw, disc_pop, disc_inc];         % State for A & W.      
RHS_bk = [Ni_bk, Nj_bk, disc_pop, disc_inc];         % State for Burger King.      
RHS_hvy = [Ni_hvy, Nj_hvy, disc_pop, disc_inc];      % State for Harvey's.      
RHS_mcd = [Ni_mcd, Nj_mcd, disc_pop, disc_inc];      % State for McDonald's.      
RHS_wdy = [Ni_wdy, Nj_wdy, disc_pop, disc_inc];      % State for Wendy's.      

X = [RHS_aw; RHS_bk; RHS_hvy; RHS_mcd; RHS_wdy];
T = [1.*(year == 1970), 1.*(year == 1970), 1.*(year == 1970), 1.*(year == 1970)];
T = [T; T; T; T; T];
avgstate = round(mean(X.*T));

end