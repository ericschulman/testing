% Cannibal Burger.                                       %
% By Mitsuru Igami and Nathan Yang.                      %
% Forward simulation for counterfactual                  %
% February 11, 2014.                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function criterion = forwardsim_other(gamma, P_mcd, T1, T2, theta_mcd, theta_other, avgstate)

% Basic setting
beta = 0.90;             % Discount factor
NS = 10000;              % Number of simulations
T = 35;                  % Number of years
I = 5;                   % Number of players
narg = 10;               % Number of arguments in period profit (including epsilon)
Beta = ones(T,1);        % 36-year vector of discount factor
for t = 1:T
    Beta(t) = beta^(t-1);
end
numactions = 3;          % Number of actions (i.e., exit, no change, enter).   

% Reshape the CCP's, which are the argument used in optimization.

% Parse out average states.
avg_ni = avgstate(1);
avg_nj = avgstate(2);
avg_z1 = avgstate(3);
avg_z2 = avgstate(4);

% Create random draws.
seed = 645456;           % Seed value for random draws
rng(seed);               % Set the seed
U1 = rand(NS,T);         % Draw shocks for population transition.

seed = 645457;           % Seed value for random draws
rng(seed);               % Set the seed
U2 = rand(NS,T);         % Draw shocks for income transition.  

seed = 645458;           % Seed value for random draws
rng(seed);               % Set the seed
U3 = rand(NS*T,I*3);     % Draw shocks for structural IID error.
Epsilons = -log(-log(U3));   % Private cost shock epsilon (iid extreme value)

seed = 645459;           % Seed value for random draws
rng(seed);               % Set the seed
U4 = rand(NS,I,T);       % Draw shocks for the CCPs.

Z = zeros(NS*T,2);          % Storage for exogenous state variables  
N = zeros(NS*T,I);          % Storage for endogenous state variables  

l = ones(NS,1);                     % [1000 x 1]
Z0 = [avg_z1, avg_z2];              % [1 x 2]
Z0 = kron(Z0,l);                    % [1000 x 3]
Z(1:NS,:) = Z0;                     % First 1000 rows of [35000 x 3]
    
N0 = [avg_ni, avg_ni, avg_ni, avg_ni, avg_ni];         % [1 x 5]
N0 = kron(N0,l);                                       % [1000 x 5]
N(1:NS,:) = N0;   

for t = 1:T
        
    Zt = Z((t-1)*NS+1:t*NS,:);              % Today's exogenous state:  [NS x 3] = [1000 x 3]
    Nt = N((t-1)*NS+1:t*NS,:);              % Today's endogenous state: [NS x 5] = [1000 x 5]
        
    epsilon = Epsilons((t-1)*NS+1:t*NS,:);  % Today's epsilons: [NS x (I*3)] = [1000 x 15]
           
    % Today's exogenous state (z1,z2,z3)
    dz1 = Zt(:,1);
    dz2 = Zt(:,2);
            
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Transision of Z --> Z' %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
        
    u1 = U1(:,t);            % Randomly drawn from uniform distribution for population transition.
    u2 = U2(:,t);            % Randomly drawn from uniform distribution for income transition. 
            
    zprime1 = (l.*1.*(dz1 == 0)).* ((0.*1.*(u1 <= T1(1,1))) + (1.*l.*1.*(u1 > T1(1,1)) & u1 <= T1(1,1)+T1(1,2)) + (2.*l.*1.*(u1 > T1(1,1)+T1(1,2)) & u1 <= T1(1,1)+T1(1,2)+T1(1,3)) + (3.*l.*1.*(u1 > T1(1,1)+T1(1,2)+T1(1,3)))) ... 
            + (l.*1.*(dz1 == 1)).* ((0.*1.*(u1 <= T1(2,1))) + (1.*l.*1.*(u1 > T1(2,1)) & u1 <= T1(2,1)+T1(2,2)) + (2.*l.*1.*(u1 > T1(2,1)+T1(2,2)) & u1 <= T1(2,1)+T1(2,2)+T1(2,3)) + (3.*l.*1.*(u1 > T1(2,1)+T1(2,2)+T1(2,3)))) ...
            + (l.*1.*(dz1 == 2)).* ((0.*1.*(u1 <= T1(3,1))) + (1.*l.*1.*(u1 > T1(3,1)) & u1 <= T1(3,1)+T1(3,2)) + (2.*l.*1.*(u1 > T1(3,1)+T1(3,2)) & u1 <= T1(3,1)+T1(3,2)+T1(3,3)) + (3.*l.*1.*(u1 > T1(3,1)+T1(3,2)+T1(3,3)))) ...
            + (l.*1.*(dz1 == 3)).* ((0.*1.*(u1 <= T1(4,1))) + (1.*l.*1.*(u1 > T1(4,1)) & u1 <= T1(4,1)+T1(4,2)) + (2.*l.*1.*(u1 > T1(4,1)+T1(4,2)) & u1 <= T1(4,1)+T1(4,2)+T1(4,3)) + (3.*l.*1.*(u1 > T1(4,1)+T1(4,2)+T1(4,3))));
            
    zprime2 = (l.*1.*(dz2 == 0)).* ((0.*1.*(u2 <= T2(1,1))) + (1.*l.*1.*(u2 > T2(1,1)) & u2 <= T2(1,1)+T1(1,2)) + (2.*l.*1.*(u2 > T2(1,1)+T2(1,2)) & u2 <= T2(1,1)+T2(1,2)+T2(1,3)) + (3.*l.*1.*(u2 > T2(1,1)+T2(1,2)+T2(1,3)))) ... 
            + (l.*1.*(dz2 == 1)).* ((0.*1.*(u2 <= T2(2,1))) + (1.*l.*1.*(u2 > T2(2,1)) & u2 <= T2(2,1)+T1(2,2)) + (2.*l.*1.*(u2 > T2(2,1)+T2(2,2)) & u2 <= T2(2,1)+T2(2,2)+T2(2,3)) + (3.*l.*1.*(u2 > T2(2,1)+T2(2,2)+T2(2,3)))) ...
            + (l.*1.*(dz2 == 2)).* ((0.*1.*(u2 <= T2(3,1))) + (1.*l.*1.*(u2 > T2(3,1)) & u2 <= T2(3,1)+T1(3,2)) + (2.*l.*1.*(u2 > T2(3,1)+T2(3,2)) & u2 <= T2(3,1)+T2(3,2)+T2(3,3)) + (3.*l.*1.*(u2 > T2(3,1)+T2(3,2)+T2(3,3)))) ...
            + (l.*1.*(dz2 == 3)).* ((0.*1.*(u2 <= T2(4,1))) + (1.*l.*1.*(u2 > T2(4,1)) & u2 <= T2(4,1)+T1(4,2)) + (2.*l.*1.*(u2 > T2(4,1)+T2(4,2)) & u2 <= T2(4,1)+T2(4,2)+T2(4,3)) + (3.*l.*1.*(u2 > T2(4,1)+T2(4,2)+T2(4,3))));
            
    zprime = [zprime1, zprime2];

    if t < T
        Z(t*NS+1:(t+1)*NS,:) = zprime;      % Record next-period Z, for all simulated draws.    
    end
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Defining Current State (N_it) %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    % Number of own shops (in state space; capped at 3)
    ni_aw  = 1*(Nt(:,1) <= 3).*Nt(:,1) + 1*(Nt(:,1) > 3)*3;
    ni_bk  = 1*(Nt(:,2) <= 3).*Nt(:,2) + 1*(Nt(:,2) > 3)*3;
    ni_hvy = 1*(Nt(:,3) <= 3).*Nt(:,3) + 1*(Nt(:,3) > 3)*3;
    ni_mcd = 1*(Nt(:,4) <= 3).*Nt(:,4) + 1*(Nt(:,4) > 3)*3;
    ni_wdy = 1*(Nt(:,5) <= 3).*Nt(:,5) + 1*(Nt(:,5) > 3)*3;
               
    % Number of rival shops (in state space; capped at 3)
    nj_aw  = Nt(:,2) + Nt(:,3) + Nt(:,4) + Nt(:,5);
    nj_bk  = Nt(:,1) + Nt(:,3) + Nt(:,4) + Nt(:,5);
    nj_hvy = Nt(:,1) + Nt(:,2) + Nt(:,4) + Nt(:,5);
    nj_mcd = Nt(:,1) + Nt(:,2) + Nt(:,3) + Nt(:,5);
    nj_wdy = Nt(:,1) + Nt(:,2) + Nt(:,3) + Nt(:,4);

    nj_aw  = 1*(nj_aw  <= 3).*nj_aw  + 1*(nj_aw  > 3)*3;    
    nj_bk  = 1*(nj_bk  <= 3).*nj_bk  + 1*(nj_bk  > 3)*3;    
    nj_hvy = 1*(nj_hvy <= 3).*nj_hvy + 1*(nj_hvy > 3)*3;     
    nj_mcd = 1*(nj_mcd <= 3).*nj_mcd + 1*(nj_mcd > 3)*3;      
    nj_wdy = 1*(nj_wdy <= 3).*nj_wdy + 1*(nj_wdy > 3)*3;     
        
    x_aw  = [ones(NS,1), ni_aw, nj_aw, dz1, dz2, ni_aw.^2, nj_aw.^2];    % [1000 x 5]
    x_bk  = [ones(NS,1), ni_bk, nj_bk, dz1, dz2, ni_bk.^2, nj_bk.^2];   
    x_hvy = [ones(NS,1), ni_hvy, nj_hvy, dz1, dz2, ni_hvy.^2, nj_hvy.^2];
    x_mcd = [ni_mcd, nj_mcd, dz1, dz2];
    x_wdy = [ones(NS,1), ni_wdy, nj_wdy, dz1, dz2, ni_wdy.^2, nj_wdy.^2];
        
    % Market type indicator.
    type2 = zeros(length(ni_aw),1);         % Focus on high type market.
    type3 = zeros(length(ni_aw),1);         % Focus on high type market.
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Simulate Actions according to Policy Function %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    % Get state ID #s corresponding to the simulated states in x_all: [5000x5] --> [5000x1]
    %stateID_aw = (4*4*4)*x_aw(:,1) + (4*4)*x_aw(:,2) + 4*(x_aw(:,3)) + (x_aw(:,4) + ones(NS,1));
    %stateID_bk = (4*4*4)*x_bk(:,1) + (4*4)*x_bk(:,2) + 4*(x_bk(:,3)) + (x_bk(:,4) + ones(NS,1));
    %stateID_hvy = (4*4*4)*x_hvy(:,1) + (4*4)*x_hvy(:,2) + 4*(x_hvy(:,3)) + (x_hvy(:,4) + ones(NS,1));
    stateID_mcd = (4*4*4)*x_mcd(:,1) + (4*4)*x_mcd(:,2) + 4*(x_mcd(:,3)) + (x_mcd(:,4) + ones(NS,1));
    %stateID_wdy = (4*4*4)*x_wdy(:,1) + (4*4)*x_wdy(:,2) + 4*(x_wdy(:,3)) + (x_wdy(:,4) + ones(NS,1));

    % Get choice probs corresponding to the state ID#s, from the policy function. [5000 x 3]
    P_tilde_mcd = P_mcd(stateID_mcd,:);
    %P_tilde_bk = P_other(stateID_bk,:);
    %P_tilde_hvy = P_other(stateID_hvy,:);
    %P_tilde_wdy = P_other(stateID_wdy,:);
    
    % Parametric approximation of McDonald's counterfactual CCP.
    x_other = [x_aw; x_bk; x_hvy; x_wdy];
    gamma_other = reshape(gamma,size(x_other,2),numactions-1);
    Pexit_other = exp(x_other*gamma_other(:,1))./(ones(NS*4,1)+exp(x_other*gamma_other(:,1))+exp(x_other*gamma_other(:,2)));
    Penter_other = exp(x_other*gamma_other(:,2))./(ones(NS*4,1)+exp(x_other*gamma_other(:,1))+exp(x_other*gamma_other(:,2)));
    Pnochange_other = ones(NS*4,1) - Pexit_other - Penter_other;
    
    Pexit_tilde_other = reshape(Pexit_other,NS,4);
    Penter_tilde_other = reshape(Penter_other,NS,4);
    Pnochange_tilde_other = reshape(Pnochange_other,NS,4);
        
    P_tilde_aw = [Pexit_tilde_other(:,1), Pnochange_tilde_other(:,1), Penter_tilde_other(:,1)];
    P_tilde_bk = [Pexit_tilde_other(:,2), Pnochange_tilde_other(:,2), Penter_tilde_other(:,2)];
    P_tilde_hvy = [Pexit_tilde_other(:,3), Pnochange_tilde_other(:,3), Penter_tilde_other(:,3)];
    P_tilde_wdy = [Pexit_tilde_other(:,4), Pnochange_tilde_other(:,4), Penter_tilde_other(:,4)];
       
    U = U4(:,:,t);
            
    a_aw = -1*1*(U(:,1) <= P_tilde_aw(:,1)) + 1*(U(:,1) > (1 - P_tilde_aw(:,3)));
    a_bk = -1*1*(U(:,2) <= P_tilde_bk(:,1)) + 1*(U(:,2) > (1 - P_tilde_bk(:,3)));
    a_hvy = -1*1*(U(:,3) <= P_tilde_hvy(:,1)) + 1*(U(:,3) > (1 - P_tilde_hvy(:,3)));
    a_mcd = -1*1*(U(:,4) <= P_tilde_mcd(:,1)) + 1*(U(:,4) > (1 - P_tilde_mcd(:,3)));
    a_wdy = -1*1*(U(:,5) <= P_tilde_wdy(:,1)) + 1*(U(:,5) > (1 - P_tilde_wdy(:,3)));

    A = [a_aw, a_bk, a_hvy, a_mcd, a_wdy];
            
    %%%%%%%%%%%%%%%%%%%%%%%%%%
    % Transision of N --> N' %
    %%%%%%%%%%%%%%%%%%%%%%%%%%
               
    % Calculate & save tomorrow's number of shops
    N2raw = Nt + A;    % N' = N + A (in raw numbers of stores) [1000 x 5]
    N2 = N2raw.*(1*(N2raw > 0 & N2raw <= 3)) + 0.*(1*(N2raw < 0)) + 3.*(1*(N2raw > 3));
    if t < T
        N(t*NS+1:(t+1)*NS, :) = N2;     % The t-th [1000 x 5] of [35000 x 5]
    end
               
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Calculate Period Profit %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    % The "actual" profit shocks (i.e., the epsilon that is associated with the chosen action): [1000 x 1] per (i,t)
    euler = 0.5772*ones(NS,1);
    P_tilde_aw_nonzero = P_tilde_aw  .* (P_tilde_aw  > .0001) + .0001 .* (P_tilde_aw  <= .0001);   % Avoid NaN by limiting prob >= .0001
    P_tilde_bk_nonzero = P_tilde_bk  .* (P_tilde_bk  > .0001) + .0001 .* (P_tilde_bk  <= .0001);   % Avoid NaN by limiting prob >= .0001
    P_tilde_hvy_nonzero = P_tilde_hvy.* (P_tilde_hvy > .0001) + .0001 .* (P_tilde_hvy <= .0001);   % Avoid NaN by limiting prob >= .0001
    P_tilde_mcd_nonzero = P_tilde_mcd.* (P_tilde_mcd > .0001) + .0001 .* (P_tilde_mcd <= .0001);   % Avoid NaN by limiting prob >= .0001
    P_tilde_wdy_nonzero = P_tilde_wdy.* (P_tilde_wdy > .0001) + .0001 .* (P_tilde_wdy <= .0001);   % Avoid NaN by limiting prob >= .0001
    ep_aw = [euler - log(P_tilde_aw_nonzero(:,1)), euler - log(P_tilde_aw_nonzero(:,2)), euler - log(P_tilde_aw_nonzero(:,3))];
    ep_bk = [euler - log(P_tilde_bk_nonzero(:,1)), euler - log(P_tilde_bk_nonzero(:,2)), euler - log(P_tilde_bk_nonzero(:,3))];
    ep_hvy = [euler - log(P_tilde_hvy_nonzero(:,1)), euler - log(P_tilde_hvy_nonzero(:,2)), euler - log(P_tilde_hvy_nonzero(:,3))];
    ep_mcd = [euler - log(P_tilde_mcd_nonzero(:,1)), euler - log(P_tilde_mcd_nonzero(:,2)), euler - log(P_tilde_mcd_nonzero(:,3))];
    ep_wdy = [euler - log(P_tilde_wdy_nonzero(:,1)), euler - log(P_tilde_wdy_nonzero(:,2)), euler - log(P_tilde_wdy_nonzero(:,3))];
    epsilon = [ep_aw, ep_bk, ep_hvy, ep_mcd, ep_wdy];
    e_aw  = (1*(a_aw < 0)) .* epsilon(:,1) + (1*(a_aw==0)) .* epsilon(:,2) + (1*(a_aw > 0)) .* epsilon(:,3);
    e_bk  = (1*(a_bk < 0)) .* epsilon(:,4) + (1*(a_bk==0)) .* epsilon(:,5) + (1*(a_bk > 0)) .* epsilon(:,6);
    e_hvy = (1*(a_hvy < 0)).* epsilon(:,7) + (1*(a_hvy==0)).* epsilon(:,8) + (1*(a_hvy > 0)).* epsilon(:,9);
    e_mcd = (1*(a_mcd < 0)).* epsilon(:,10) + (1*(a_mcd==0)).* epsilon(:,11) + (1*(a_mcd > 0)).*epsilon(:,12);
    e_wdy = (1*(a_wdy < 0)).* epsilon(:,13) + (1*(a_wdy==0)).* epsilon(:,14) + (1*(a_wdy > 0)).*epsilon(:,15);
               
    % 10 arguments of profit = (const, Ni, Nj, dz1, dz2, kappa(+), kappa(-), epsilon): [1000 x 1] per (i,t)
    pi_aw = [ni_aw, ni_aw.*ni_aw, ni_aw.*nj_aw, ni_aw.*dz1, ni_aw.*dz2, -1*(a_aw>0), -1*(a_aw<0), type2.*ni_aw, type3.*ni_aw, e_aw];
    pi_bk = [ni_bk, ni_bk.*ni_bk, ni_bk.*nj_bk, ni_bk.*dz1, ni_bk.*dz2, -1*(a_bk>0), -1*(a_bk<0), type2.*ni_bk, type3.*ni_bk, e_bk];
    pi_hvy = [ni_hvy, ni_hvy.*ni_hvy, ni_hvy.*nj_hvy, ni_hvy.*dz1, ni_hvy.*dz2, -1*(a_hvy>0), -1*(a_hvy<0), type2.*ni_hvy, type3.*ni_hvy, e_hvy];
    pi_mcd = [ni_mcd, ni_mcd.*ni_mcd, ni_mcd.*nj_mcd, ni_mcd.*dz1, ni_mcd.*dz2, -1*(a_mcd>0), -1*(a_mcd<0), type2.*ni_mcd, type3.*ni_mcd, e_mcd];
    pi_wdy = [ni_wdy, ni_wdy.*ni_wdy, ni_wdy.*nj_wdy, ni_wdy.*dz1, ni_wdy.*dz2, -1*(a_wdy>0), -1*(a_wdy<0), type2.*ni_wdy, type3.*ni_wdy, e_wdy];

    % Expected profits: Take average over 1000 simulations
    avgpi_aw  = (1/NS) * sum(pi_aw, 1);  
    avgpi_bk  = (1/NS) * sum(pi_bk, 1);
    avgpi_hvy = (1/NS) * sum(pi_hvy, 1);
    avgpi_mcd = (1/NS) * sum(pi_mcd, 1);
    avgpi_wdy = (1/NS) * sum(pi_wdy, 1);
        
    % Record today's average profits (9 arguments)
    Pi_aw(t,:)  = avgpi_aw;  
    Pi_bk(t,:)  = avgpi_bk;
    Pi_hvy(t,:) = avgpi_hvy;
    Pi_mcd(t,:) = avgpi_mcd;
    Pi_wdy(t,:) = avgpi_wdy;
 
end  
    
% Expected value = Sum of discounted profits
V_aw = Beta' * Pi_aw;   
V_bk = Beta' * Pi_bk;
V_hvy = Beta' * Pi_hvy;
V_mcd = Beta' * Pi_mcd;
V_wdy = Beta' * Pi_wdy;
V_other = [V_aw; V_bk; V_hvy; V_wdy];

% Use estimated parameters to calculated forward-simulated profits.
V = V_other(1:(narg-1))*theta_other + V_other(narg);

% Construct criterion for fmincon optimization (i.e., minization problem).
% Note: As V increases, criterion should decrease.
criterion = 1/(V+10);

end  