% Cannibal Burger.                                       %
% By Mitsuru Igami and Nathan Yang.                      %
% Main code for Kasahara and Shimotsu (2009).            %                   
% September 25, 2013.                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load canadafastfood3
load states1                    % Load smaller state matrix (5*2*2*2, 5).
load states2                    % Load larger state matrix (5*2*2*2*5*2*2*2, 5) that contains lagged states.
load states_fix                 % Load fixed states to iterate over in for-loop.

S = length(states_fix);         % Number of states.
typevector = zeros(S,1);        % Store the number of types in vector.

for s = 1:S
    numtypes = typecount(states_fix(s,:), states1, states2, data)              % Calculate number of KS types for each fixed state. 
    typevector(s) = numtypes;                                                  % Store number of KS types for each fixed state.
end

KS_types = [states_fix, typevector];       % Store the number of types for each fixed state.

save('KS_types.mat','KS_types');           % Save the number of types for each fixed state in matrix format.
csvwrite('KS_types.csv', KS_types);        % Save the number of types for each fixed state in csv format. 
