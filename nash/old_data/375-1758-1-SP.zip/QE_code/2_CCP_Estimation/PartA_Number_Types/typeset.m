% Cannibal Burger.                                       %
% By Mitsuru Igami and Nathan Yang.                      %
% Assign markets to types.                               %                   
% October 3, 2013.                                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [typeassignment] = typeset(data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Legend for different types.
% Type 1 = Low population, income, property value, and zero total outlets.
% Type 3 = High population, income, property value, and 4 total outlets.
% outlets.
% Type 2 = Any market that does not belong to 1 or 3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parse out data.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clusterid = data(:,1);      % Unique market ID.
year = data(:,2);           % Year.
N_aw = data(:,3);           % Number of A & W outlets (in data).
N_bk = data(:,4);           % Number of Burger King outlets (in data).
N_hvy = data(:,5);          % Number of Harvey's outlets (in data).
N_mcd = data(:,6);          % Number of McDonald's outlets (in data).
N_wdy = data(:,7);          % Number of Wendy's outlets (in data).
lagN_aw = data(:,8);        % Lagged number of A & W outlets.
lagN_bk = data(:,9);        % Lagged number of Burger King outlets.
lagN_hvy = data(:,10);      % Lagged number of Harvey's outlets. 
lagN_mcd = data(:,11);      % Lagged number of McDonald's outlets.    
lagN_wdy = data(:,12);      % Lagged number of Wendy's outlets
fwdN_aw = data(:,13);       % Forward (next period) number of A & W outlets.
fwdN_bk = data(:,14);       % Forward (next period) number of Burger King outlets.
fwdN_hvy = data(:,15);      % Forward (next period) number of Harvey's outlets.
fwdN_mcd = data(:,16);      % Forward (next period) number of McDonald's outlets.
fwdN_wdy = data(:,17);      % Forward (next period) number of Wendy's outlets.
a_aw = data(:,18);          % Action (change in number of outlets) for A & W.
a_bk = data(:,19);          % Action (change in number of outlets) for Burger King.
a_hvy = data(:,20);         % Action (change in number of outlets) for Harvey's.    
a_mcd = data(:,21);         % Action (change in number of outlets) for McDonald's.
a_wdy = data(:,22);         % Action (change in number of outlets) for Wendy's.
fsaid = data(:,23);         % FSA ID.
pop = data(:,24);           % Population.
inc = data(:,26);           % Income
val = data(:,25);           % Property value
cityid = data(:,27);        % City id (?).
lagpop = data(:,34);        % Lagged population.
laginc = data(:,35);        % Lagged income.    
lagval = data(:,36);        % Lagged property value.    
lag2pop = data(:,37);       % Lagged 2 periods population.
lag2inc = data(:,38);       % Lagged 2 periods income.
lag2val = data(:,39);       % Lagged 2 periods property value.
lag3pop = data(:,40);       % Lagged 3 periods population.
lag3inc = data(:,41);       % Lagged 3 periods income.
lag3val = data(:,42);       % Lagged 3 periods property value.
fwdpop = data(:,43);        % Forward (next period) population.
fwdinc = data(:,44);        % Forward (next period) income.    
fwdval = data(:,45);        % Forward (next period) property value.
lag2N_aw = data(:,46);      % Lagged 2 periods number of A & W.
lag2N_bk = data(:,47);      % Lagged 2 periods number of Burger King.
lag2N_hvy = data(:,48);     % Lagged 2 periods number of Harvey's.    
lag2N_mcd = data(:,49);     % Lagged 2 periods number of McDonald's.    
lag2N_wdy = data(:,50);     % Lagged 2 periods number of Wendy's.    
lag3N_aw = data(:,51);      % Lagged 3 periods number of A & W.
lag3N_bk = data(:,52);      % Lagged 3 periods number of Burger King.
lag3N_hvy = data(:,53);     % Lagged 3 periods number of Harvey's.    
lag3N_mcd = data(:,54);     % Lagged 3 periods number of McDonald's.    
lag3N_wdy = data(:,55);     % Lagged 3 periods number of Wendy's.

MT = size(data,1);          % Size of the dataset (M x T).

% Divide years into three groups, t = 1, 2, 3, 4, or 5.
t = mod(year,5);    % Bin years into three time subgroups (i.e., 1970 -> 1, 1971 -> 2, 1972 ->3, 1973 -> 4, 1974 -> 5, 1975 -> 1, etc...).        
t = t+1;            % Make t either 1, 2, 3, 4, or 5.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construction of variables for non-parametric estimation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Number of own shops (in state space; capped at 2), from the perspective of each firm
N = N_aw + N_bk + N_hvy + N_mcd + N_wdy;
N = 1*(N <= 4).*N + 1*(N > 4)*4;

% Lagged number of own shops (in state space; capped at 2), from the perspective of each firm
lagN = lagN_aw + lagN_bk + lagN_hvy + lagN_mcd + lagN_wdy;
lagN = 1*(lagN <= 4).*lagN + 1*(lagN > 4)*4;

% 2 periods lagged number of own shops (in state space; capped at 2), from the perspective of each firm
lag2N = lag2N_aw + lag2N_bk + lag2N_hvy + lag2N_mcd + lag2N_wdy;
lag2N = 1*(lag2N <= 4).*lag2N + 1*(lag2N > 4)*4;

% 3 periods lagged number of own shops (in state space; capped at 2), from the perspective of each firm
lag3N = lag3N_aw + lag3N_bk + lag3N_hvy + lag3N_mcd + lag3N_wdy;
lag3N = 1*(lag3N <= 4).*lag3N + 1*(lag3N > 4)*4;

% Next period number of own shops (in state space; capped at 2), from the perspective of each firm
fwdN = fwdN_aw + fwdN_bk + fwdN_hvy + fwdN_mcd + fwdN_wdy;
fwdN = 1*(fwdN <= 4).*fwdN + 1*(fwdN > 4)*4;

% Obtain quantiles for main market characteristics.
pop50 = quantile(pop,0.5);  % 20295.59; 
inc50 = quantile(inc,0.5);  % 50008.75; 
val50 = quantile(val,0.5);  % 148362.0; 

o = ones(length(data),1);
disc_pop = o.*1.*(pop <= pop50) + 2.*o.*1.*(pop > pop50);  
disc_inc = o.*1.*(inc <= inc50) + 2.*o.*1.*(inc > inc50);  
disc_val = o.*1.*(val <= val50) + 2.*o.*1.*(val > val50);  

lagdisc_pop = lagpop;  
lagdisc_inc = laginc;  
lagdisc_val = lagval; 

lag2disc_pop = lag2pop;  
lag2disc_inc = lag2inc;  
lag2disc_val = lag2val; 

lag3disc_pop = lag3pop;  
lag3disc_inc = lag3inc;  
lag3disc_val = lag3val; 

fwddisc_pop = fwdpop;  
fwddisc_inc = fwdinc;  
fwddisc_val = fwdval; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assign to different market types.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

markettype = 2*ones(MT,1);
lagmarkettype = 2*ones(MT,1);
lag2markettype = 2*ones(MT,1);

for i = 1:MT
    if disc_pop(i) == 1 && disc_inc(i) == 1 && disc_val(i) == 1 && N(i) == 0
        markettype(i) = 1;
    elseif disc_pop(i) == 2 && disc_inc(i) == 2 && disc_val(i) == 2 && N(i) == 4    
        markettype(i) = 3;
    end
    
    if lagdisc_pop(i) == 1 && lagdisc_inc(i) == 1 && lagdisc_val(i) == 1 && lagN(i) == 0
        lagmarkettype(i) = 1;
    elseif lagdisc_pop(i) == 2 && lagdisc_inc(i) == 2 && lagdisc_val(i) == 2 && lagN(i) == 4    
        lagmarkettype(i) = 3;
    end
    
    if lag2disc_pop(i) == 1 && lag2disc_inc(i) == 1 && lag2disc_val(i) == 1 && lag2N(i) == 0
        lag2markettype(i) = 1;
    elseif lag2disc_pop(i) == 2 && lag2disc_inc(i) == 2 && lag2disc_val(i) == 2 && lag2N(i) == 4    
        lag2markettype(i) = 3;
    end
    
end
 
typeassignment = [markettype, lagmarkettype, lag2markettype];

end
