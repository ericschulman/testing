% Cannibal Burger.                                       %
% By Mitsuru Igami and Nathan Yang.                      %
% Main code for obtaining mixture distribution.          %                   
% October 10, 2013.                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load canadafastfood3
load states_fix_mixture                    % All possible realized states. 

M = 3;                                     % Number of types.
numtypes = 3;                              % M - 1.
numstates = length(states_fix_mixture);    % Number of realized states. 
Vmatrix = zeros(numstates,numtypes);       % Storing the mixture distributions from each simulation draw.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finding the mixture distribution.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for s = 1:numstates
    fixstate = states_fix_mixture(s,:);
    Vmatrix(s,:) = mixture(data,fixstate);             % Store the identified mixture distribution.
end    

Vmatrix = Vmatrix(~any(isnan(Vmatrix),2),:);           % Ignore the NaN cases. 
Pi_init = mean(Vmatrix);

save('Vmatrix.mat','Vmatrix');           % Save the pi's for each fixed state in matrix format.
csvwrite('Vmatrix.csv', Vmatrix);        % Save the pi's for each fixed state in csv format. 

save('Pi_init.mat','Pi_init');           % Save the averaged pi's for each fixed state in matrix format.
csvwrite('Pi_init.csv', Pi_init);        % Save the averaged pi's for each state in csv format.
