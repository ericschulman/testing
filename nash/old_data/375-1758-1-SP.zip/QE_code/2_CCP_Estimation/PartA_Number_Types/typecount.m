% Cannibal Burger.                                       %
% By Mitsuru Igami and Nathan Yang.                      %
% Main code for Kasahara and Shimotsu (2009).            %                   
% September 17, 2013.                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function numtypes = typecount(fixvector, states1, states2, data)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parse out data.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clusterid = data(:,1);      % Unique market ID.
year = data(:,2);           % Year.
N_aw = data(:,3);           % Number of A & W outlets (in data).
N_bk = data(:,4);           % Number of Burger King outlets (in data).
N_hvy = data(:,5);          % Number of Harvey's outlets (in data).
N_mcd = data(:,6);          % Number of McDonald's outlets (in data).
N_wdy = data(:,7);          % Number of Wendy's outlets (in data).
lagN_aw = data(:,8);        % Lagged number of A & W outlets.
lagN_bk = data(:,9);        % Lagged number of Burger King outlets.
lagN_hvy = data(:,10);      % Lagged number of Harvey's outlets. 
lagN_mcd = data(:,11);      % Lagged number of McDonald's outlets.    
lagN_wdy = data(:,12);      % Lagged number of Wendy's outlets
fwdN_aw = data(:,13);       % Forward (next period) number of A & W outlets.
fwdN_bk = data(:,14);       % Forward (next period) number of Burger King outlets.
fwdN_hvy = data(:,15);      % Forward (next period) number of Harvey's outlets.
fwdN_mcd = data(:,16);      % Forward (next period) number of McDonald's outlets.
fwdN_wdy = data(:,17);      % Forward (next period) number of Wendy's outlets.
a_aw = data(:,18);          % Action (change in number of outlets) for A & W.
a_bk = data(:,19);          % Action (change in number of outlets) for Burger King.
a_hvy = data(:,20);         % Action (change in number of outlets) for Harvey's.    
a_mcd = data(:,21);         % Action (change in number of outlets) for McDonald's.
a_wdy = data(:,22);         % Action (change in number of outlets) for Wendy's.
fsaid = data(:,23);         % FSA ID.
pop = data(:,24);           % Population.
inc = data(:,26);           % Income
val = data(:,25);           % Property value
cityid = data(:,27);        % City id (?).
lagpop = data(:,34);        % Lagged population.
laginc = data(:,35);        % Lagged income.    
lagval = data(:,36);        % Lagged property value.    
lag2pop = data(:,37);       % Lagged 2 periods population.
lag2inc = data(:,38);       % Lagged 2 periods income.
lag2val = data(:,39);       % Lagged 2 periods property value.
lag3pop = data(:,40);       % Lagged 3 periods population.
lag3inc = data(:,41);       % Lagged 3 periods income.
lag3val = data(:,42);       % Lagged 3 periods property value.
fwdpop = data(:,43);        % Forward (next period) population.
fwdinc = data(:,44);        % Forward (next period) income.    
fwdval = data(:,45);        % Forward (next period) property value.
lag2N_aw = data(:,46);      % Lagged 2 periods number of A & W.
lag2N_bk = data(:,47);      % Lagged 2 periods number of Burger King.
lag2N_hvy = data(:,48);     % Lagged 2 periods number of Harvey's.    
lag2N_mcd = data(:,49);     % Lagged 2 periods number of McDonald's.    
lag2N_wdy = data(:,50);     % Lagged 2 periods number of Wendy's.    
lag3N_aw = data(:,51);      % Lagged 3 periods number of A & W.
lag3N_bk = data(:,52);      % Lagged 3 periods number of Burger King.
lag3N_hvy = data(:,53);     % Lagged 3 periods number of Harvey's.    
lag3N_mcd = data(:,54);     % Lagged 3 periods number of McDonald's.    
lag3N_wdy = data(:,55);     % Lagged 3 periods number of Wendy's.

MT = size(data,1);          % Size of the dataset (M x T).

% Divide years into three groups, t = 1, 2, 3, 4, or 5.
t = mod(year,5);    % Bin years into three time subgroups (i.e., 1970 -> 1, 1971 -> 2, 1972 ->3, 1973 -> 4, 1974 -> 5, 1975 -> 1, etc...).        
t = t+1;            % Make t either 1, 2, 3, 4, or 5.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construction of variables for non-parametric estimation.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Number of own shops (in state space; capped at 2), from the perspective of each firm
N = N_aw + N_bk + N_hvy + N_mcd + N_wdy;
N = 1*(N <= 4).*N + 1*(N > 4)*4;

% Lagged number of own shops (in state space; capped at 2), from the perspective of each firm
lagN = lagN_aw + lagN_bk + lagN_hvy + lagN_mcd + lagN_wdy;
lagN = 1*(lagN <= 4).*lagN + 1*(lagN > 4)*4;

% 2 periods lagged number of own shops (in state space; capped at 2), from the perspective of each firm
lag2N = lag2N_aw + lag2N_bk + lag2N_hvy + lag2N_mcd + lag2N_wdy;
lag2N = 1*(lag2N <= 4).*lag2N + 1*(lag2N > 4)*4;

% 3 periods lagged number of own shops (in state space; capped at 2), from the perspective of each firm
lag3N = lag3N_aw + lag3N_bk + lag3N_hvy + lag3N_mcd + lag3N_wdy;
lag3N = 1*(lag3N <= 4).*lag3N + 1*(lag3N > 4)*4;

% Next period number of own shops (in state space; capped at 2), from the perspective of each firm
fwdN = fwdN_aw + fwdN_bk + fwdN_hvy + fwdN_mcd + fwdN_wdy;
fwdN = 1*(fwdN <= 4).*fwdN + 1*(fwdN > 4)*4;

% Obtain quantiles for main market characteristics.
pop50 = quantile(pop,0.5);  % 20295.59; 
inc50 = quantile(inc,0.5);  % 50008.75; 
val50 = quantile(val,0.5);  % 148362.0; 

o = ones(length(data),1);
disc_pop = o.*1.*(pop <= pop50) + 2.*o.*1.*(pop > pop50);  
disc_inc = o.*1.*(inc <= inc50) + 2.*o.*1.*(inc > inc50);  
disc_val = o.*1.*(val <= val50) + 2.*o.*1.*(val > val50);  

lagdisc_pop = lagpop;  
lagdisc_inc = laginc;  
lagdisc_val = lagval; 

lag2disc_pop = lag2pop;  
lag2disc_inc = lag2inc;  
lag2disc_val = lag2val; 

lag3disc_pop = lag3pop;  
lag3disc_inc = lag3inc;  
lag3disc_val = lag3val; 

fwddisc_pop = fwdpop;  
fwddisc_inc = fwdinc;  
fwddisc_val = fwdval; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construction of the inner P matrix (t = 4, 2).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% For NP (inner matrix).

% Use other state matrix with lagged values.
n = states2(:,1);               % Number of outlets: {0,1,2,3,4+}.
dz1 = states2(:,2);              % Discretized population state: {1,2}.
dz2 = states2(:,3);              % Discretized income state: {1,2}.
dz3 = states2(:,4);              % Discretized property value state: {1,2}.
lagn = states2(:,5);            % Number of outlets: {0,1,2,3,4+}.
lagdz1 = states2(:,6);           % Discretized population state: {1,2}.
lagdz2 = states2(:,7);           % Discretized income state: {1,2}.
lagdz3 = states2(:,8);          % Discretized property value state: {1,2}.
S = size(states2,1);             % Size of the statespace (5*2*2*2*5*2*2*2 = 1600)
 
% Get non-parametric (frequency) estimates of entry/exit policy.
fixstate_data = [lag3N, lag3disc_pop, lag3disc_inc, lag3disc_val, lagN, lagdisc_pop, lagdisc_inc, lagdisc_val, fwdN, fwddisc_pop, fwddisc_inc, fwddisc_val];

X_aw = [N, disc_pop, disc_inc, disc_val, lag2N, lag2disc_pop, lag2disc_inc, lag2disc_val, t, fixstate_data];            % State for A & W.      
X_bk = [N, disc_pop, disc_inc, disc_val, lag2N, lag2disc_pop, lag2disc_inc, lag2disc_val, t, fixstate_data];            % State for Burger King.      
X_hvy = [N, disc_pop, disc_inc, disc_val, lag2N, lag2disc_pop, lag2disc_inc, lag2disc_val, t, fixstate_data];      % State for Harvey's.      
X_mcd = [N, disc_pop, disc_inc, disc_val, lag2N, lag2disc_pop, lag2disc_inc, lag2disc_val, t, fixstate_data];      % State for McDonald's.      
X_wdy = [N, disc_pop, disc_inc, disc_val, lag2N, lag2disc_pop, lag2disc_inc, lag2disc_val, t, fixstate_data];      % State for Wendy's.      

% Construct fixed states used for constructing P.
% t = 1, 3, fix states in t = 2, 4. 
% Note: If fix state in t = 5, not enough observations, and get pretty much all NaNs.
tgroup = 3*ones(length(n),1);
fixstate1 = [fixvector(1)*ones(length(n),1),fixvector(4)*ones(length(n),1),fixvector(5)*ones(length(n),1),fixvector(6)*ones(length(n),1)];
fixstate2 = [fixvector(2)*ones(length(n),1),fixvector(4)*ones(length(n),1),fixvector(5)*ones(length(n),1),fixvector(6)*ones(length(n),1)];
fixstate3 = [fixvector(3)*ones(length(n),1),fixvector(4)*ones(length(n),1),fixvector(5)*ones(length(n),1),fixvector(6)*ones(length(n),1)];

X = [X_aw; X_bk; X_hvy; X_mcd; X_wdy];  % Stack states in data.
y = [a_aw; a_bk; a_hvy; a_mcd; a_wdy];  % Stack actions in data.

% Construct different states depending on the time.
x = [n, dz1, dz2, dz3, lagn, lagdz1, lagdz2, lagdz3, tgroup, fixstate1, fixstate2, fixstate3];            % State-space grid for t = 1, 2.    

% Initialize nonparametric probabilities.
NP = zeros(S,3);                             % Initialize policy function (State size * 3 actions) for t = 1, 2.

% Components for nonparametric estimation.
MTI = size(y,1);    % Size of effective data = M * T * I (5 symmetric players)
SV = size(x,2);     % Number of state variables (= 5)
z = zeros(MTI,SV);  % Initialize matrix for some intermediate operations
l = ones(MTI,1);    % Column vector of ones, for intermediate operations 
k = zeros(MTI,SV);  % State (s) in data --> state variable (sv)
bound = 1e-10;      % Threshold to filter-out negligible choice probabilities

% For time periods belonging to t = 2, 4.
for s = 1:S                    % For each of the 5184 states
    for sv = 1:SV              % For each of the 10 state variables
        
       z(:,sv) = x(s,sv) * l;
       k(:,sv) = (1*(X(:,sv) == z(:,sv)));    % 1 if state variable (sv) experienced state (s) in data
       
    end
    
    kt = k';
    K = prod(kt)';                              
    D = sum(K);                                  
    w = K/D;                                       % Probability that X = z.
    f_minus = (1 * (y < 0)) .* w;                  % Weight(?) of exit/reduce.
    f_plus  = (1 * (y > 0)) .* w;                  % Weight(?) of enter/add.
    NP(s,1) = sum(f_minus);                        % Choice prob of a = -1.
    NP(s,3) = sum(f_plus);                         % Choice prob of a = +1.
    NP(s,2) = 1 - NP(s,1) - NP(s,3);               % Choice prob of a = 0.
    NP(s,1) = 1*(abs(NP(s,1)) > bound) * NP(s,1);  % Set negligible prob to 0.
    NP(s,2) = 1*(abs(NP(s,2)) > bound) * NP(s,2);  % Set negligible prob to 0.
    NP(s,3) = 1*(abs(NP(s,3)) > bound) * NP(s,3);  % Set negligible prob to 0.
    
end

%save('NP.mat','NP');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construction of the P1 (first column) and P2 (first row) vectors.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% For P1 (first column).

% Use other state matrix without lagged values.
n = states1(:,1);               % Number of outlets: {0,1,2,3,4+}.
dz1 = states1(:,2);              % Discretized population state: {1,2}.
dz2 = states1(:,3);              % Discretized income state: {1,2}.
dz3 = states1(:,4);              % Discretized property value state: {1,2}.
S = size(states1,1);             % Size of the statespace (5*2*2*2 = 40)

% Get non-parametric (frequency) estimates of entry/exit policy.
fixstate_data = [lagN, lagdisc_pop, lagdisc_inc, lagdisc_val, fwdN, fwddisc_pop, fwddisc_inc, fwddisc_val];

X_aw = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];          % State for A & W.      
X_bk = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];          % State for Burger King.      
X_hvy = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];      % State for Harvey's.      
X_mcd = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];      % State for McDonald's.      
X_wdy = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];      % State for Wendy's.      

% Construct fixed states used for constructing P.
% t = 1, fix states in t = 2, 4.
tgroup = 1*ones(length(n),1);
fixstate1 = [fixvector(2)*ones(length(n),1),fixvector(4)*ones(length(n),1),fixvector(5)*ones(length(n),1),fixvector(6)*ones(length(n),1)];
fixstate2 = [fixvector(3)*ones(length(n),1),fixvector(4)*ones(length(n),1),fixvector(5)*ones(length(n),1),fixvector(6)*ones(length(n),1)];

X = [X_aw; X_bk; X_hvy; X_mcd; X_wdy];  % Stack states in data.
y = [a_aw; a_bk; a_hvy; a_mcd; a_wdy];  % Stack actions in data.

% Construct different states depending on the time.
x = [n, dz1, dz2, dz3, tgroup, fixstate1, fixstate2];            % State-space grid for t = 1.    

% Components for nonparametric estimation.
MTI = size(y,1);    % Size of effective data = M * T * I (5 symmetric players)
SV = size(x,2);     % Number of state variables (= 5)
z = zeros(MTI,SV);  % Initialize matrix for some intermediate operations
l = ones(MTI,1);    % Column vector of ones, for intermediate operations 
k = zeros(MTI,SV);  % State (s) in data --> state variable (sv)
bound = 1e-10;      % Threshold to filter-out negligible choice probabilities

% Initialize nonparametric probabilities.
P1 = zeros(S,3);                             % Initialize policy function (State size * 3 actions) for t = 1.

% For time periods belonging to t = 1.
for s = 1:S                    % For each of the 72 states
    for sv = 1:SV              % For each of the 5 state variables
        
       z(:,sv) = x(s,sv) * l;
       k(:,sv) = (1*(X(:,sv) == z(:,sv)));    % 1 if state variable (sv) experienced state (s) in data
       
    end
    
    kt = k';
    K = prod(kt)';                              
    D = sum(K);                                  
    w = K/D;                                       % Probability that X = z.
    f_minus = (1 * (y < 0)) .* w;                  % Weight(?) of exit/reduce.
    f_plus  = (1 * (y > 0)) .* w;                  % Weight(?) of enter/add.
    P1(s,1) = sum(f_minus);                        % Choice prob of a = -1.
    P1(s,3) = sum(f_plus);                         % Choice prob of a = +1.
    P1(s,2) = 1 - P1(s,1) - P1(s,3);               % Choice prob of a = 0.
    P1(s,1) = 1*(abs(P1(s,1)) > bound) * P1(s,1);  % Set negligible prob to 0.
    P1(s,2) = 1*(abs(P1(s,2)) > bound) * P1(s,2);  % Set negligible prob to 0.
    P1(s,3) = 1*(abs(P1(s,3)) > bound) * P1(s,3);  % Set negligible prob to 0.
    
end

%save('P1.mat','P1');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% For P2 (first row).

% Use other state matrix without lagged values.
n = states1(:,1);               % Number of outlets: {0,1,2,3,4+}.
dz1 = states1(:,2);              % Discretized population state: {1,2}.
dz2 = states1(:,3);              % Discretized income state: {1,2}.
dz3 = states1(:,4);              % Discretized property value state: {1,2}.
S = size(states1,1);             % Size of the statespace (5*2*2*2 = 40)

% Get non-parametric (frequency) estimates of entry/exit policy.
fixstate_data = [lag3N, lag3disc_pop, lag3disc_inc, lag3disc_val, lagN, lagdisc_pop, lagdisc_inc, lagdisc_val];

X_aw = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];          % State for A & W.      
X_bk = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];          % State for Burger King.      
X_hvy = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];      % State for Harvey's.      
X_mcd = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];      % State for McDonald's.      
X_wdy = [N, disc_pop, disc_inc, disc_val, t, fixstate_data];      % State for Wendy's.      

% Construct fixed states used for constructing P.
% t = 3, fix states in t = 2, 4.
% Note: If fix state in t = 5, not enough observations, and get pretty much all NaNs.
tgroup = 3*ones(length(n),1);
fixstate1 = [fixvector(1)*ones(length(n),1),fixvector(4)*ones(length(n),1),fixvector(5)*ones(length(n),1),fixvector(6)*ones(length(n),1)];
fixstate2 = [fixvector(2)*ones(length(n),1),fixvector(4)*ones(length(n),1),fixvector(5)*ones(length(n),1),fixvector(6)*ones(length(n),1)];

X = [X_aw; X_bk; X_hvy; X_mcd; X_wdy];  % Stack states in data.
y = [a_aw; a_bk; a_hvy; a_mcd; a_wdy];  % Stack actions in data.

% Construct different states depending on the time.
x = [n, dz1, dz2, dz3, tgroup, fixstate1, fixstate2];            % State-space grid for t = 3.    

% Components for nonparametric estimation.
MTI = size(y,1);    % Size of effective data = M * T * I (5 symmetric players)
SV = size(x,2);     % Number of state variables (= 5)
z = zeros(MTI,SV);  % Initialize matrix for some intermediate operations
l = ones(MTI,1);    % Column vector of ones, for intermediate operations 
k = zeros(MTI,SV);  % State (s) in data --> state variable (sv)
bound = 1e-10;      % Threshold to filter-out negligible choice probabilities

% Initialize nonparametric probabilities.
P2 = zeros(S,3);                             % Initialize policy function (State size * 3 actions) for t = 3.

% For time periods belonging to t = 4.
for s = 1:S                    % For each of the 72 states
    for sv = 1:SV              % For each of the 5 state variables
        
       z(:,sv) = x(s,sv) * l;
       k(:,sv) = (1*(X(:,sv) == z(:,sv)));    % 1 if state variable (sv) experienced state (s) in data
       
    end
    
    kt = k';
    K = prod(kt)';                              
    D = sum(K);                                  
    w = K/D;                                       % Probability that X = z.
    f_minus = (1 * (y < 0)) .* w;                  % Weight(?) of exit/reduce.
    f_plus  = (1 * (y > 0)) .* w;                  % Weight(?) of enter/add.
    P2(s,1) = sum(f_minus);                        % Choice prob of a = -1.
    P2(s,3) = sum(f_plus);                         % Choice prob of a = +1.
    P2(s,2) = 1 - P2(s,1) - P2(s,3);               % Choice prob of a = 0.
    P2(s,1) = 1*(abs(P2(s,1)) > bound) * P2(s,1);  % Set negligible prob to 0.
    P2(s,2) = 1*(abs(P2(s,2)) > bound) * P2(s,2);  % Set negligible prob to 0.
    P2(s,3) = 1*(abs(P2(s,3)) > bound) * P2(s,3);  % Set negligible prob to 0.
    
end

%save('P2.mat','P2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Identification of the number of types (KS, 2009).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Pinner = construct_p(states1,states2,NP(:,3));   % Construct (72,72) inner matrix of probabilities P.
%save('Pinner.mat','Pinner');                     % Save (72,72) inner matrox of probabilities used to construct P.   
Pinner = [P2(:,3)'; Pinner];                     % Add first row to P matrix.
Padd = [1; P1(:,3)];                             % Construct first column of P matrix.
P = [Padd, Pinner];                              % Add first column to P matrix.
P(isnan(P)) = 0 ;                                % Change NaN cells into 0.
%save('P.mat','P');                               % Save (73,73) matrix P.
numtypes = rank(P);                              % Number of market types.     

end
