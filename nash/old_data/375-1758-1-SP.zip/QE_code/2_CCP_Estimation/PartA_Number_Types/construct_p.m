% Dynamic Spatial Oligopoly.                          %
% By Mitsuru Igami and Nathan Yang.                   %
% Construct the P matrix in Kasahara and Shimotsu.    %                   
% August 20, 2013.                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function P = construct_p(states1,states2,NP)

N1 = size(states1,1);
N2 = size(states2,1);

% Create matrix to store state indices.
P = ones(N1,N1);

% Loop over all data observations and states.
for i = 1:N1
    for j = 1:N1
        for k = 1:N2
            if [states1(i,:),states1(j,:)] == states2(k,:);       % Check and see if combined states (i,j) matches state k.
                P(i,j) = NP(k);            % Match (i,j) element with nonparametric probabilities.
                break                      % Go to next (i,j) combo if it matches with k.
            end
        end
    end
end


end
