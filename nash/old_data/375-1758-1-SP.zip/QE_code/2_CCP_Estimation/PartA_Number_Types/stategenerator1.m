% Dynamic Spatial Oligopoly.                          %
% By Mitsuru Igami and Nathan Yang.                   %
% Code for generate all possible states.              %                   
% December 18, 2012.                                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function states = stategenerator1(set1,set2)

numstates = 4;

% How many possible states per chain.
N1 = length(set1);          % Market structure states.
N2 = length(set2);          % Market characteristic states.

% Initialize the state generator.
states = ones(1,numstates);

for i = 1:N1
    for j = 1:N2
        for k = 1:N2
            for l = 1:N2
                    addstate = [set1(i), set2(j), set2(k), set2(l)];       % Iterate through all possible states.
                    states = [states; addstate];                                    % Collect all possible states in matrix.
            end
        end
    end
end

states = states(2:length(states),:);                        % State matrix for output.

end