% Cannibal Burger.                                       %
% By Mitsuru Igami and Nathan Yang.                      %
% Main code for obtaining mixture distribution.          %                   
% October 10, 2013.                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function V = mixture(data,fixstates)

% Number of types.
M = 3; 
numtypes = M - 1;

% Parse out data.
clusterid = data(:,1);      % Unique market ID.
year = data(:,2);           % Year.
N_aw = data(:,3);           % Number of A & W outlets (in data).
N_bk = data(:,4);           % Number of Burger King outlets (in data).
N_hvy = data(:,5);          % Number of Harvey's outlets (in data).
N_mcd = data(:,6);          % Number of McDonald's outlets (in data).
N_wdy = data(:,7);          % Number of Wendy's outlets (in data).
lagN_aw = data(:,8);        % Lagged number of A & W outlets.
lagN_bk = data(:,9);        % Lagged number of Burger King outlets.
lagN_hvy = data(:,10);      % Lagged number of Harvey's outlets. 
lagN_mcd = data(:,11);      % Lagged number of McDonald's outlets.    
lagN_wdy = data(:,12);      % Lagged number of Wendy's outlets
fwdN_aw = data(:,13);       % Forward (next period) number of A & W outlets.
fwdN_bk = data(:,14);       % Forward (next period) number of Burger King outlets.
fwdN_hvy = data(:,15);      % Forward (next period) number of Harvey's outlets.
fwdN_mcd = data(:,16);      % Forward (next period) number of McDonald's outlets.
fwdN_wdy = data(:,17);      % Forward (next period) number of Wendy's outlets.
a_aw = data(:,18);          % Action (change in number of outlets) for A & W.
a_bk = data(:,19);          % Action (change in number of outlets) for Burger King.
a_hvy = data(:,20);         % Action (change in number of outlets) for Harvey's.    
a_mcd = data(:,21);         % Action (change in number of outlets) for McDonald's.
a_wdy = data(:,22);         % Action (change in number of outlets) for Wendy's.
fsaid = data(:,23);         % FSA ID.
pop = data(:,24);           % Population.
inc = data(:,26);           % Income
val = data(:,25);           % Property value
cityid = data(:,27);        % City id (?).
lagpop = data(:,34);        % Lagged population.
laginc = data(:,35);        % Lagged income.    
lagval = data(:,36);        % Lagged property value.    
lag2pop = data(:,37);       % Lagged 2 periods population.
lag2inc = data(:,38);       % Lagged 2 periods income.
lag2val = data(:,39);       % Lagged 2 periods property value.
lag3pop = data(:,40);       % Lagged 3 periods population.
lag3inc = data(:,41);       % Lagged 3 periods income.
lag3val = data(:,42);       % Lagged 3 periods property value.
fwdpop = data(:,43);        % Forward (next period) population.
fwdinc = data(:,44);        % Forward (next period) income.    
fwdval = data(:,45);        % Forward (next period) property value.
lag2N_aw = data(:,46);      % Lagged 2 periods number of A & W.
lag2N_bk = data(:,47);      % Lagged 2 periods number of Burger King.
lag2N_hvy = data(:,48);     % Lagged 2 periods number of Harvey's.    
lag2N_mcd = data(:,49);     % Lagged 2 periods number of McDonald's.    
lag2N_wdy = data(:,50);     % Lagged 2 periods number of Wendy's.    
lag3N_aw = data(:,51);      % Lagged 3 periods number of A & W.
lag3N_bk = data(:,52);      % Lagged 3 periods number of Burger King.
lag3N_hvy = data(:,53);     % Lagged 3 periods number of Harvey's.    
lag3N_mcd = data(:,54);     % Lagged 3 periods number of McDonald's.    
lag3N_wdy = data(:,55);     % Lagged 3 periods number of Wendy's.

MT = size(data,1);          % Size of the dataset (M x T).

% Parse out fixed states.
fixpop = fixstates(1);
fixinc = fixstates(2);
fixval = fixstates(3);
fixN = fixstates(4);
lagfixpop = fixstates(5);
lagfixinc = fixstates(6);
lagfixval = fixstates(7);
lagfixN = fixstates(8);
lag2fixpop = fixstates(9);
lag2fixinc = fixstates(10);
lag2fixval = fixstates(11);
lag2fixN = fixstates(12);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct main variables.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Number of own shops (in state space; capped at 2), from the perspective of each firm
N = N_aw + N_bk + N_hvy + N_mcd + N_wdy;
N = 1*(N <= 4).*N + 1*(N > 4)*4;
Nlarge = 1*(N >= 1);

% Lagged number of own shops (in state space; capped at 2), from the perspective of each firm
lagN = lagN_aw + lagN_bk + lagN_hvy + lagN_mcd + lagN_wdy;
lagN = 1*(lagN <= 4).*lagN + 1*(lagN > 4)*4;
lagNlarge = 1*(lagN >= 1);

% 2 periods lagged number of own shops (in state space; capped at 2), from the perspective of each firm
lag2N = lag2N_aw + lag2N_bk + lag2N_hvy + lag2N_mcd + lag2N_wdy;
lag2N = 1*(lag2N <= 4).*lag2N + 1*(lag2N > 4)*4;
lag2Nlarge = 1*(lag2N >= 1);

% Obtain quantiles for main market characteristics.
pop50 = quantile(pop,0.5);  % 20295.59; 
inc50 = quantile(inc,0.5);  % 50008.75; 
val50 = quantile(val,0.5);  % 148362.0; 

o = ones(length(data),1);
disc_pop = o.*1.*(pop <= pop50) + 2.*o.*1.*(pop > pop50);  
disc_inc = o.*1.*(inc <= inc50) + 2.*o.*1.*(inc > inc50);  
disc_val = o.*1.*(val <= val50) + 2.*o.*1.*(val > val50);  

lagdisc_pop = lagpop;  
lagdisc_inc = laginc;  
lagdisc_val = lagval; 

lag2disc_pop = lag2pop;  
lag2disc_inc = lag2inc;  
lag2disc_val = lag2val; 

%lag3disc_pop = lag3pop;  
%lag3disc_inc = lag3inc;  
%lag3disc_val = lag3val; 

%fwddisc_pop = fwdpop;  
%fwddisc_inc = fwdinc;  
%fwddisc_val = fwdval; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct main state variables for P and Pk matrices.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

types = ones(MT,3);                 % States for t, t-1, and t-2.

for m = 1:MT
    % For t. 
    if disc_pop(m) == fixpop && disc_inc(m) == fixinc && disc_val(m) == fixval && N(m) == fixN
        types(m,1) = 1;
    elseif disc_pop(m) == lagfixpop && disc_inc(m) == lagfixinc && disc_val(m) == lagfixval && N(m) == lagfixN
        types(m,1) = 2;
    else
        types(m,1) = 3;
    end
    
    % For t-1.
    if lagdisc_pop(m) == fixpop && lagdisc_inc(m) == fixinc && lagdisc_val(m) == fixval && lagN(m) == fixN
        types(m,2) = 1;
    elseif lagdisc_pop(m) == lagfixpop && lagdisc_inc(m) == lagfixinc && lagdisc_val(m) == lagfixval && lagN(m) == lagfixN
        types(m,2) = 2;
    else
        types(m,2) = 3;
    end
    
    % For t-2.
    if lag2disc_pop(m) == fixpop && lag2disc_inc(m) == fixinc && lag2disc_val(m) == fixval && lag2N(m) == fixN
        types(m,3) = 1;
    elseif lag2disc_pop(m) == lagfixpop && lag2disc_inc(m) == lagfixinc && lag2disc_val(m) == lagfixval && lag2N(m) == lagfixN
        types(m,3) = 2;
    else
        types(m,3) = 3;
    end
end    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct P matrix.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

P1 = zeros(numtypes,1);             % First column of P matrix.
P2 = zeros(numtypes,1);             % First row of P matrix.
P12 = zeros(numtypes,numtypes);     % Inner matrix in P.    

% First column and first row.
for t = 1:numtypes
    P1(t) = sum(Nlarge.*1.*(types(:,1) == t))/MT;        
    P2(t) = sum(lagNlarge.*1.*(types(:,2) == t))/MT;
end

% Inner matrix.
for s = 1:numtypes
    for t = 1:numtypes
        denom = sum(lagNlarge.*1.*(types(:,2) == s));
        numer = sum(Nlarge.*lagNlarge.*1.*(types(:,2) == s & types(:,1) == t));
        P12(t,s) = numer/denom;
    end
    
end

Pinner = [P2'; P12];                     % Add first row to P matrix.
Padd = [1; P1];                          % Construct first column of P matrix.
P = [Padd, Pinner];                      % Add first column to P matrix.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct Pk matrix.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fixk = 2;                               % Fixed state for constructing Pk matrix. 

P1k = zeros(numtypes,1);                % First column of Pk matrix.
P2k = zeros(numtypes,1);                % First row of Pk matrix.
P12k = zeros(numtypes,numtypes);        % Inner matrix in Pk.

% First column and first row.
for t = 1:numtypes
    P1k(t) = sum(Nlarge.*lag2Nlarge.*1.*(types(:,1) == t & types(:,3) == fixk))/sum(1.*(types(:,3) == fixk));
    P2k(t) = sum(lagNlarge.*lag2Nlarge.*1.*(types(:,2) == t & types(:,3) == fixk))/sum(1.*(types(:,3) == fixk));
end

% Inner matrix.
for s = 1:numtypes
    for t = 1:numtypes
        denom = sum(lagNlarge.*lag2Nlarge.*1.*(types(:,2) == s & types(:,3) == fixk));
        numer = sum(Nlarge.*lagNlarge.*lag2Nlarge.*1.*(types(:,2) == s & types(:,1) == t & types(:,3) == fixk));
        P12k(t,s) = numer/denom;
    end
    
end

Fk = sum(1.*(types(:,3) == fixk))/MT;        % (1,1) element in Pk matrix.
Pinnerk = [P2k'; P12k];                     % Add first row to Pk matrix.
Paddk = [Fk; P1k];                          % Construct first column of Pk matrix.
Pk = [Paddk, Pinnerk];                      % Add first column to Pk matrix.

% Obtain mixture distribution using KS matrix method.
Pmult = inv(P)*Pk;
Pmult(isnan(Pmult)) = 0;                                % Change NaN cells into 0.
[V, Dk] = eig(Pmult);
L = inv(V);
V = inv(L')*P*inv(L);
V = diag(V);
V = abs(V)/sum(abs(V));                                % Mixture distribution (i.e., pi's).
V = V';

end
