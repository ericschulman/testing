% Calculate Q from (Pi,P,F,D,X)
function Q = updateQ(Pi,P,F,D,X)

global I J M T NS NT;               % Dimension indeces
    
Q = zeros(M,NT);                    % initialize the output

for n = 1:M

    Numer = ones(1,NT);             % Initialize the numerator
    
    for s = 1:NT
       
        for t = 1:(T-1)
            
            Numer(s) = Numer(s)...
                * ((P(1,1,X(1,t,n),s) * F(1,1,X(1,t,n),X(1,t+1,n),s)) ^ D(1,1,n,t))...    % Firm 1's exit      in year (t)
                * ((P(1,2,X(1,t,n),s) * F(1,2,X(1,t,n),X(1,t+1,n),s)) ^ D(1,2,n,t))...    % Firm 1's no-change in year (t)
                * ((P(1,3,X(1,t,n),s) * F(1,3,X(1,t,n),X(1,t+1,n),s)) ^ D(1,3,n,t))...    % Firm 1's entry     in year (t)
                * ((P(2,1,X(2,t,n),s) * F(2,1,X(2,t,n),X(2,t+1,n),s)) ^ D(2,1,n,t))...    % Firm 2's exit      in year (t)
                * ((P(2,2,X(2,t,n),s) * F(2,2,X(2,t,n),X(2,t+1,n),s)) ^ D(2,2,n,t))...    % Firm 2's no-change in year (t)
                * ((P(2,3,X(2,t,n),s) * F(2,3,X(2,t,n),X(2,t+1,n),s)) ^ D(2,3,n,t))...    % Firm 2's entry     in year (t)
                * ((P(3,1,X(3,t,n),s) * F(3,1,X(3,t,n),X(3,t+1,n),s)) ^ D(3,1,n,t))...    % Firm 3's exit      in year (t)
                * ((P(3,2,X(3,t,n),s) * F(3,2,X(3,t,n),X(3,t+1,n),s)) ^ D(3,2,n,t))...    % Firm 3's no-change in year (t)
                * ((P(3,3,X(3,t,n),s) * F(3,3,X(3,t,n),X(3,t+1,n),s)) ^ D(3,3,n,t))...    % Firm 3's entry     in year (t)
                * ((P(4,1,X(4,t,n),s) * F(4,1,X(4,t,n),X(4,t+1,n),s)) ^ D(4,1,n,t))...    % Firm 4's exit      in year (t)
                * ((P(4,2,X(4,t,n),s) * F(4,2,X(4,t,n),X(4,t+1,n),s)) ^ D(4,2,n,t))...    % Firm 4's no-change in year (t)
                * ((P(4,3,X(4,t,n),s) * F(4,3,X(4,t,n),X(4,t+1,n),s)) ^ D(4,3,n,t))...    % Firm 4's entry     in year (t)
                * ((P(5,1,X(5,t,n),s) * F(5,1,X(5,t,n),X(5,t+1,n),s)) ^ D(5,1,n,t))...    % Firm 5's exit      in year (t)
                * ((P(5,2,X(5,t,n),s) * F(5,2,X(5,t,n),X(5,t+1,n),s)) ^ D(5,2,n,t))...    % Firm 5's no-change in year (t)
                * ((P(5,3,X(5,t,n),s) * F(5,3,X(5,t,n),X(5,t+1,n),s)) ^ D(5,3,n,t));      % Firm 5's entry     in year (t)
            %fprintf('\n Numer for Prob(Market %3.0f = Type %1.0f) at time %2.0f: %4.64f',n,s,t,Numer(s));
        end
        
        Numer(s) = Pi(s) * Numer(s);
        %fprintf('\n Numerator for Prob(Market %3.0f = Type %1.0f): %4.72f',n,s,Numer(s));
        
    end
    
    denom = sum(Numer(:));      % Denominator is just the sum of S numerators
    Q(n,:) = Numer(:) / denom;  % Probability that market (n) belongs to type (s)
    
end

% Note: Ingredients must have the following forms.
%
% Q  = [q_1L,   q_1M,   q_1H;
%       q_2L,   q_2M,   q_2H;
%                ...
%       q_400L, q_400M, q_400H]                         (M * NT = 400 * 3)
%
% Pi = [pi_L, pi_M, pi_H]                               (1 * NT = 1 * 3)
%
% P  = [p_mcd-, p_mcd0, p_mcd+;
%       p_aw-,  p_aw0,  p_aw+;
%       p_bk-,  p_bk0,  p_bk+;
%       p_hvy-, p_hvy0, p_hvy+;
%       p_wdy-, p_wdy0, p_wdy+]                         (I * J = 5 * 3)
%       * NS[256] * NT[3]
%       ... Actually, p_aw(:) = p_bk(:) = p_hvy(:) = p_wdy(:) = p_other(:)!
%
% F  = [f_mcd-, f_mcd0, f_mcd+;
%       f_aw-,  f_aw0,  f_aw+;
%       f_bk-,  f_bk0,  f_bk+;
%       f_hvy-, f_hvy0, f_hvy+;
%       f_wdy-, f_wdy0, f_wdy+]                         (I * J = 5 * 3)
%       * NS^2[256^2] * NT[3]
%
% D  = [d_mcd-, d_mcd0, d_mcd+;
%       d_aw-,  d_aw0,  d_aw+;
%       d_bk-,  d_bk0,  d_bk+;
%       d_hvy-, d_hvy0, d_hvy+;
%       d_wdy-, d_wdy0, d_wdy+]                         (I * J = 5 * 3)
%       * M[400] * (T-1)[34]
%
% X  = [x_mcd_1, x_mcd_2, ..., x_mcd_34, x_mcd_35;
%       x_aw_1,  x_aw_2,  ..., x_aw_34,  x_aw_35;
%       x_bk_1,  x_bk_2,  ..., x_bk_34,  x_bk_35;
%       x_hvy_1, x_hvy_2, ..., x_hvy_34, x_hvy_35;
%       x_wdy_1, x_wdy_2, ..., x_wdy_34, x_wdy_35;]     (I * T = 5 * 35)
%       * M[400]
% where x_i_t is a state index (1 through 256) of the form: 1 + N_it + 4 * N_-it + (4*4) * Z1_t + (4*4*4) * Z2_t
%