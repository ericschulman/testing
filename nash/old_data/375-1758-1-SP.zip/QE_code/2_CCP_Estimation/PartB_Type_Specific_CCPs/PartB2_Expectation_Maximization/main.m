% Arcidiacono-Miller 1st-stage estimation of CCP with 3 market types

global I J M T NS NT...   % Dimension indeces
     RHS_mcd RHS_aw RHS_bk RHS_hvy RHS_wdy a_mcd a_aw a_bk a_hvy a_wdy Ni Nj dz1 dz2... % Key data for 'updateP.m'
     F_Ni F_dz1 F_dz2;  % Key input to 'updateF.m'

% Initialize dimensions
I = 5;          % Number of players (firms). Index is 'i'.
J = 3;          % Number of discrete alternatives {-,0,+}. Index is 'j'.
M = 400;        % Number of markets. Index is 'n' (to match Arcidiacono-Miller).
T = 35;         % Number of years. Index is 't'.
NS = 256;       % Number of states: (Ni,Nj,Z1,Z2) = 4 * 4 * 4 * 4. Index is 'x' (to match Arcidiacono-Miller).
NT = 3;         % Number of market types: {Low, Mid, High}. Index is 's' (to match Arcidiacono-Miller).

%% Load & label the state space grid
load gamestates                 % Load state matrix (4*4*4*4, 4).
Ni = states(:,1);               % Number of own outlets: {0,1,2,3+}.
Nj = states(:,2);               % Number of rival outlets: {0,1,2,3+}.
dz1 = states(:,3);              % Discretized population state: {0,1,2,3}.
dz2 = states(:,4);              % Discretized income state: {0,1,2,3}.

%% Load & label the data
% For adequate 'updateP.m' operation, the data for our Arcidiacono-Miller operation should be sorted first by year, and then by market!
load canadafastfood_resorted.mat;    

% Labeling
MT = size(data,1);          % Size of the dataset (M x T = 400 x 35 = 14000).
clusterid = data(:,1);      % Unique market ID.
year = data(:,2);           % Year.
N_aw = data(:,3);           % Number of A & W outlets (in data).
N_bk = data(:,4);           % Number of Burger King outlets (in data).
N_hvy = data(:,5);          % Number of Harvey's outlets (in data).
N_mcd = data(:,6);          % Number of McDonald's outlets (in data).
N_wdy = data(:,7);          % Number of Wendy's outlets (in data).
lagN_aw = data(:,8);        % Lagged number of outlets.
lagN_bk = data(:,9);        
lagN_hvy = data(:,10);      
lagN_mcd = data(:,11);      
lagN_wdy = data(:,12);      
fwdN_aw = data(:,13);       % Forward (next period) number of outlets.
fwdN_bk = data(:,14);       
fwdN_hvy = data(:,15);      
fwdN_mcd = data(:,16);      
fwdN_wdy = data(:,17);      
a_aw = data(:,18);          % Action (change in number of outlets) for A & W.
a_bk = data(:,19);          % Action (change in number of outlets) for Burger King.
a_hvy = data(:,20);         % Action (change in number of outlets) for Harvey's.    
a_mcd = data(:,21);         % Action (change in number of outlets) for McDonald's.
a_wdy = data(:,22);         % Action (change in number of outlets) for Wendy's.
fsaid = data(:,23);         % FSA ID.
pop = data(:,24);           % Population.
inc = data(:,26);           % Income
val = data(:,25);           % Residential property value
cityid = data(:,27);        % City id (?).
fpop = data(:,28);          % Population at (t+1)
finc = data(:,29);          % Income at (t+1)
fval = data(:,30);          % Residential property value at (t+1)
mktfe = data(:,31);         % Market fixed effect estimates (from 130913_alaToivanenWaterson3_Fixedeffect3quantile.csv/dta)
tertile = data(:,32);       % Market type initial guess (from 130913_alaToivanenWaterson3_Fixedeffect3quantile.csv/dta)

% Number of own shops (in state space; capped at 3), from the perspective of each firm
Ni_aw = 1*(N_aw <= 3).*N_aw + 1*(N_aw > 3)*3;
Ni_bk = 1*(N_bk <= 3).*N_bk + 1*(N_bk > 3)*3;
Ni_hvy = 1*(N_hvy <= 3).*N_hvy + 1*(N_hvy > 3)*3;
Ni_mcd = 1*(N_mcd <= 3).*N_mcd + 1*(N_mcd > 3)*3;
Ni_wdy = 1*(N_wdy <= 3).*N_wdy + 1*(N_wdy > 3)*3;

% Number of rival shops (in state space; capped at 3), from the perspective of each firm
Nj_aw = N_bk + N_hvy + N_mcd + N_wdy;
Nj_bk = N_aw + N_hvy + N_mcd + N_wdy;
Nj_hvy = N_aw + N_bk + N_mcd + N_wdy;
Nj_mcd = N_aw + N_bk + N_hvy + N_wdy;
Nj_wdy = N_aw + N_bk + N_hvy + N_mcd;

Nj_aw = 1*(Nj_aw <= 3).*Nj_aw + 1*(Nj_aw > 3)*3;     
Nj_bk = 1*(Nj_bk <= 3).*Nj_bk + 1*(Nj_bk > 3)*3;
Nj_hvy = 1*(Nj_hvy <= 3).*Nj_hvy + 1*(Nj_hvy > 3)*3;
Nj_mcd = 1*(Nj_mcd <= 3).*Nj_mcd + 1*(Nj_mcd > 3)*3;
Nj_wdy = 1*(Nj_wdy <= 3).*Nj_wdy + 1*(Nj_wdy > 3)*3;

% Obtain 4 quantiles for main market characteristics.
pop25 = quantile(pop,0.25);   
inc25 = quantile(inc,0.25);  
pop50 = quantile(pop,0.5);  
inc50 = quantile(inc,0.5);  
pop75 = quantile(pop,0.75);   
inc75 = quantile(inc,0.75);   

o = ones(length(data),1);
disc_pop = o.*0.*(pop <= pop25) + o.*1.*(pop > pop25 & pop <= pop50) + o.*2.*(pop > pop50 & pop <= pop75) + o.*3.*(pop > pop75);  
disc_inc = o.*0.*(inc <= inc25) + o.*1.*(inc > inc25 & inc <= inc50) + o.*2.*(inc > inc50 & inc <= inc75) + o.*3.*(inc > inc75);  
disc_fpop = o.*0.*(fpop <= pop25) + o.*1.*(fpop > pop25 & fpop <= pop50) + o.*2.*(fpop > pop50 & fpop <= pop75) + o.*3.*(fpop > pop75);  
disc_finc = o.*0.*(finc <= inc25) + o.*1.*(finc > inc25 & finc <= inc50) + o.*2.*(finc > inc50 & finc <= inc75) + o.*3.*(finc > inc75);  

% Define state variables for each firm
RHS_aw = [Ni_aw, Nj_aw, disc_pop, disc_inc];         % State for A & W.      
RHS_bk = [Ni_bk, Nj_bk, disc_pop, disc_inc];         % State for Burger King.      
RHS_hvy = [Ni_hvy, Nj_hvy, disc_pop, disc_inc];      % State for Harvey's.      
RHS_mcd = [Ni_mcd, Nj_mcd, disc_pop, disc_inc];      % State for McDonald's.      
RHS_wdy = [Ni_wdy, Nj_wdy, disc_pop, disc_inc];      % State for Wendy's.      

%% Initialize key objects
fprintf('\n Initializing (Pi0, P0, F0) & preparing (D, X)... \n');
tic;

% Make Pi0, from Kasahara-Shimotsu estimates
Pi0 = [0.3531, 0.3322, 0.3147];

% To make P0, load and combine the initial CCP estimates
load P0_mcd_low.mat; load P0_mcd_mid.mat; load P0_mcd_high.mat;
load P0_other_low.mat; load P0_other_mid.mat; load P0_other_high.mat;
P_mcd = zeros(NS,J,NT);
P_other = zeros(NS,J,NT);
P_mcd(:,:,1) = P0_mcd_low;
P_mcd(:,:,2) = P0_mcd_mid;
P_mcd(:,:,3) = P0_mcd_high;
P_other(:,:,1) = P0_other_low;
P_other(:,:,2) = P0_other_mid;
P_other(:,:,3) = P0_other_high;

% Make P0, by rearranging the initial CCP estimates for the Arcidiacono-Miller iteration
P0 = zeros(I,J,NS,NT);        % 5 * 3 * 256 * 3
for i = 1:I
    for j = 1:J
        for x = 1:NS
            for s = 1:NT
                if i ==1
                    P0(i,j,x,s) = P_mcd(x,j,s);
                else
                    P0(i,j,x,s) = P_other(x,j,s);
                end
            end
        end
    end
end

% F_Ni: Own # of shops changes deterministically, as follows
F_Ni = zeros(I,J,NS,NS,NT); 
F_Ni(1,1,:,:,1) = [ones(64),  zeros(64), zeros(64), zeros(64);
                   ones(64),  zeros(64), zeros(64), zeros(64);
                   zeros(64), ones(64),  zeros(64), zeros(64);
                   zeros(64), zeros(64), ones(64),  zeros(64)];     % When a = -1 (exit)
F_Ni(1,2,:,:,1) = [ones(64),  zeros(64), zeros(64), zeros(64);
                   zeros(64), ones(64),  zeros(64), zeros(64);
                   zeros(64), zeros(64), ones(64),  zeros(64);
                   zeros(64), zeros(64), zeros(64), ones(64) ];     % When a = 0 (no change)
F_Ni(1,3,:,:,1) = [zeros(64), ones(64),  zeros(64), zeros(64);
                   zeros(64), zeros(64), ones(64),  zeros(64);
                   zeros(64), zeros(64), zeros(64), ones(64) ;
                   zeros(64), zeros(64), zeros(64), ones(64) ];     % When a = +1 (entry)
F_Ni(1,1,:,:,2:3) = repmat(F_Ni(1,1,:,:,1),[1,1,1,1,2]);
F_Ni(1,2,:,:,2:3) = repmat(F_Ni(1,2,:,:,1),[1,1,1,1,2]);
F_Ni(1,3,:,:,2:3) = repmat(F_Ni(1,3,:,:,1),[1,1,1,1,2]);
F_Ni(2:5,1,:,:,:) = repmat(F_Ni(1,1,:,:,:),[4,1,1,1,1]);    % The transition pattern is common across firms
F_Ni(2:5,2,:,:,:) = repmat(F_Ni(1,2,:,:,:),[4,1,1,1,1]);    % The transition pattern is common across firms
F_Ni(2:5,3,:,:,:) = repmat(F_Ni(1,3,:,:,:),[4,1,1,1,1]);    % The transition pattern is common across firms

% F_dz: dz1 & dz2 evolve exogenously & independently, as estimated from the data
fz1 = zeros(1,1,NS,NS,1);
fz2 = zeros(1,1,NS,NS,1);
for x0 = 1:NS
    for x1 = 1:NS
        numer1 = sum((disc_fpop == dz1(x1)) .* (disc_pop == dz1(x0)));
        numer2 = sum((disc_finc == dz2(x1)) .* (disc_inc == dz2(x0)));
        denom1 = sum((disc_pop == dz1(x0)));
        denom2 = sum((disc_inc == dz2(x0)));
        fz1(1,1,x0,x1,1) = numer1 ./ denom1;
        fz2(1,1,x0,x1,1) = numer2 ./ denom2;
    end
end
F_dz1 = repmat(fz1,[I,J,1,1,NT]); % The transition pattern is common across (i,j,mtype)
F_dz2 = repmat(fz2,[I,J,1,1,NT]); % The transition pattern is common across (i,j,mtype)

% F_dz: Make simple & intuitive (4x4) versions for exposition purposes
fz1_4x4 = zeros(4,4);
fz2_4x4 = zeros(4,4);
for x0 = 0:3
    for x1 = 0:3
        numer1 = sum((disc_fpop == x1) .* (disc_pop == x0));
        numer2 = sum((disc_finc == x1) .* (disc_inc == x0));
        denom1 = sum((disc_pop == x0));
        denom2 = sum((disc_inc == x0));
        fz1_4x4(x0+1,x1+1) = numer1 ./ denom1;
        fz2_4x4(x0+1,x1+1) = numer2 ./ denom2;
    end
end

% Make F0, from modeling assumption (F_Ni), the initial CCP (F_Nj), & the data (F_dz1 & F_dz2)
F0 = updateF(P0);   % F_Nj: Rival # of shops evolves according to the CCP (rational expectations)

% Make D, the 0/1 indicators of a_it = {-1,0,+1}, & X, the state index (1--256) for each firm-year-market data point
D = zeros(I,J,M,T-1);
X = zeros(I,T,M);
for n = 1:M
    for t = 1:T
        nt = n + M * (t - 1);   % market-year index
        
        D(:,:,n,t) = [(a_mcd(nt) < 0), (a_mcd(nt) == 0), (a_mcd(nt) > 0);
                      (a_aw(nt) < 0),  (a_aw(nt) == 0),  (a_aw(nt) > 0);
                      (a_bk(nt) < 0),  (a_bk(nt) == 0),  (a_bk(nt) > 0);
                      (a_hvy(nt) < 0), (a_hvy(nt) == 0), (a_hvy(nt) > 0);
                      (a_wdy(nt) < 0), (a_wdy(nt) == 0), (a_wdy(nt) > 0)];
                  
        X(:,t,n) = [1 + (4*4*4)*Ni_mcd(nt) + (4*4)*Nj_mcd(nt) + 4*disc_pop(nt) + disc_inc(nt);
                    1 + (4*4*4)*Ni_aw(nt)  + (4*4)*Nj_aw(nt)  + 4*disc_pop(nt) + disc_inc(nt);
                    1 + (4*4*4)*Ni_bk(nt)  + (4*4)*Nj_bk(nt)  + 4*disc_pop(nt) + disc_inc(nt);
                    1 + (4*4*4)*Ni_hvy(nt) + (4*4)*Nj_hvy(nt) + 4*disc_pop(nt) + disc_inc(nt);
                    1 + (4*4*4)*Ni_wdy(nt) + (4*4)*Nj_wdy(nt) + 4*disc_pop(nt) + disc_inc(nt)];
    end
end

% Set initial values
Pi_old = Pi0;
P_old = P0;
F_old = F0;

toc;

%% Iterate & get consistent CCP

iter = 0;
fprintf('\n iteration #%4.0f: Pi0    = [%1.4f, %1.4f, %1.4f]',iter,Pi0(1),Pi0(2),Pi0(3));

for iter = 1:100
    tic;
    
    Q_new = updateQ(Pi_old,P_old,F_old,D,X);
    
    % If Q_new contains NaN's or 0's, replace them with 0.3333...
    Q_new(isnan(Q_new)) = 1/3;
        
    Pi_new = sum(Q_new,1) / M;
    P_new = updateP(Q_new);
    F_new = updateF(P_new);
    
    Pi_old = Pi_new;
    P_old = P_new;
    F_old = F_new;
    
    fprintf('\n iteration #%4.0f: Pi_new = [%1.4f, %1.4f, %1.4f] \n',iter,Pi_new(1),Pi_new(2),Pi_new(3));  % Show something    
    toc;
end

save('Q_new.mat','Q_new');
save('Pi_new.mat','Pi_new');
save('P_new.mat','P_new');
save('F_new.mat','F_new');

% Rearrange CCPs for visual inspection & later use
P_mcd_low = zeros(NS,J);        % (state, action) | mtype = low
P_mcd_mid = zeros(NS,J);        % (state, action) | mtype = medium
P_mcd_high = zeros(NS,J);       % (state, action) | mtype = high
P_other_low = zeros(NS,J);      % (state, action) | mtype = low
P_other_mid = zeros(NS,J);      % (state, action) | mtype = medium
P_other_high = zeros(NS,J);     % (state, action) | mtype = high
for x = 1:NS
    P_mcd_low(x,:) = P_new(1,:,x,1);
    P_mcd_mid(x,:) = P_new(1,:,x,2);
    P_mcd_high(x,:) = P_new(1,:,x,3);
    P_other_low(x,:) = P_new(2,:,x,1);
    P_other_mid(x,:) = P_new(2,:,x,2);
    P_other_high(x,:) = P_new(2,:,x,3);
end
save('P_mcd_low.mat','P_mcd_low');
save('P_mcd_mid.mat','P_mcd_mid');
save('P_mcd_high.mat','P_mcd_high');
save('P_other_low.mat','P_other_low');
save('P_other_mid.mat','P_other_mid');
save('P_other_high.mat','P_other_high');

fprintf('\n done. \n');