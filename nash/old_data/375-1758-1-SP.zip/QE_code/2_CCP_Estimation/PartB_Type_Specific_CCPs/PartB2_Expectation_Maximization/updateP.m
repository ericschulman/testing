% Calculate P from (Q, data)
function P = updateP(Q)

global I J M T NS NT...   % Dimension indeces
     RHS_mcd RHS_aw RHS_bk RHS_hvy RHS_wdy a_mcd a_aw a_bk a_hvy a_wdy Ni Nj dz1 dz2;   % Key data for 'updateP.m'

P = zeros(I,J,NS,NT);

%% Construct CCP of McDonald's
RHS = RHS_mcd;                         % McDonald's states in data.
LHS = a_mcd;                         % McDonald's actions in data.
grid = [Ni, Nj, dz1, dz2];            % State-space grid (S x SV = 256 x 4)  
C_mcd = zeros(NS,1);                % Count the number of times certain state is reached, for diagnostic purposes

% Prepare auxiliary variables
MTI = size(LHS,1);    % Size of effective data = M * T * I
SV = size(grid,2);     % Number of state variables (4)
z = zeros(MTI,SV);  % Initialize matrix for checking if certain state is observed.
z01 = zeros(MTI,SV);% Initialize matrix for checking "adjacent states"
z02 = zeros(MTI,SV);% Initialize matrix for checking "adjacent states"
l = ones(MTI,1);    % Column vector of ones, for intermediate operations 
k = zeros(MTI,SV);  % Initizlize flags, of state variable (sv)'s value agreeing with definition of state (s)

% Frequency estimation
for mtype = 1:NT
    
    for state = 1:128       % For states in which Ni = 0 or 1

        for sv = 1:2        % Values of (Ni,Nj) should exactly match def. of state (s)        
           z(:,sv) = grid(state,sv) * l;               % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
           k(:,sv) = 1*(RHS(:,sv) == z(:,sv));    % =1 if state variable (sv)'s value in data agrees with def. of state (s)
        end

        for sv = 3:4        % Values of (dz1,dz2) just need to be "adjacent" to state (s)
            z(:,sv) = grid(state,sv) * l;              % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
            z01(:,sv) = (grid(state,sv) + 1) * l;      % dz1 or dz2 can take a higher value.
            z02(:,sv) = (grid(state,sv) - 1) * l;      % dz1 or dz2 can take a lower value.
            k(:,sv) = 1*(RHS(:,sv) == z(:,sv) | RHS(:,sv) == z01(:,sv) | RHS(:,sv) == z02(:,sv));   % =1 if state variable's value "fuzzily" agrees with state (s)
        end

        kt = k';        % Transpose: [MTI x SV] --> [SV x MTI]
        K = prod(kt)';  % Multiply flag elements, to focus on true flag (all state variables' values must agree with state definition)                              
        C = sum(K);     % Count the number of times state (s) is reached in data.                             
        C_mcd(state) = C;   % For diagnostic purposes
        w = K/C;        % Frequency weight: Each data point is just one of the D times that state (s) is observed in data.
        
        q = repmat(Q(:,mtype),T,1);     % Arcidiacono-Miller weighting by Prob(market n belongs to certain type)
        
        f_minus = 1 * (LHS < 0) .* w .* q;     % Count of choice == exit/reduce.
        f_plus  = 1 * (LHS > 0) .* w .* q;     % Count of choice == enter/add.
        p_minus = sum(f_minus);      % Frequency estimate: Choice prob of a = -1.
        p_plus = sum(f_plus);       % Frequency estimate: Choice prob of a = +1.
        p_zero = 1 - p_minus - p_plus;               % Choice prob of a = 0.
        
        P(1,:,state,mtype) = [p_minus, p_zero, p_plus];
        
    end

    for state = 129:192     % For states in which Ni = 2 (need data from 'adjacent' state bins to mitigate 'NaN')

        for sv = 1:2        % Values of (Ni,Nj) should exactly match def. of state (s)        
           z(:,sv) = grid(state,sv) * l;               % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
           k(:,sv) = 1*(RHS(:,sv) == z(:,sv));    % =1 if state variable (sv)'s value in data agrees with def. of state (s)
        end

        for sv = 3:4        % Values of (dz1,dz2) can be anything.
            k(:,sv) = l;    % Flag is always =1 for any values of (dz1,dz2)
        end

        kt = k';        % Transpose: [MTI x SV] --> [SV x MTI]
        K = prod(kt)';  % Multiply flag elements, to focus on true flag (all state variables' values must agree with state definition)                              
        C = sum(K);     % Count the number of times state (s) is reached in data.                             
        C_mcd(state) = C;
        w = K/C;        % Frequency weight: Each data point is just one of the D times that state (s) is observed in data.
        q = repmat(Q(:,mtype),T,1);     % Arcidiacono-Miller weighting by Prob(market n belongs to certain type)
        f_minus = 1 * (LHS < 0) .* w .* q;     % Count of choice == exit/reduce.
        f_plus  = 1 * (LHS > 0) .* w .* q;     % Count of choice == enter/add.
        p_minus = sum(f_minus);      % Frequency estimate: Choice prob of a = -1.
        p_plus = sum(f_plus);       % Frequency estimate: Choice prob of a = +1.
        p_zero = 1 - p_minus - p_plus;               % Choice prob of a = 0.
        
        P(1,:,state,mtype) = [p_minus, p_zero, p_plus];
        
    end

    % Special treatment of the 'Ni = 3+' cases (very few observations)
    P(1,1,193:256,mtype) = P(1,1,129:192,mtype);    % Pr(-|Ni=3+) := Pr(-|Ni=2)
    P(1,2,193:256,mtype) = ones(1,1,64,1) - P(1,1,193:256,mtype);
    P(1,3,193:256,mtype) = zeros(1,1,64,1);         % Pr(+|Ni=3+) := 0 by modeling assumption
    
end

%% Construct CCP of the other 4 chains

RHS = [RHS_aw; RHS_bk; RHS_hvy; RHS_wdy];  % Stack states in data.
LHS = [a_aw; a_bk; a_hvy; a_wdy];  % Stack actions in data.
grid = [Ni, Nj, dz1, dz2];          % State-space grid.    
C_other = zeros(NS,1);            % Stores a count of the number of times certain state reached.

% Prepare auxiliary variables
MTI = size(LHS,1);    % Size of effective data = M * T * I
SV = size(grid,2);     % Number of state variables (4)
z = zeros(MTI,SV);  % Initialize matrix for checking if certain state is observed.
z01 = zeros(MTI,SV);% Initialize matrix for checking "adjacent states"
z02 = zeros(MTI,SV);% Initialize matrix for checking "adjacent states"
l = ones(MTI,1);    % Column vector of ones, for intermediate operations 
k = zeros(MTI,SV);  % Initizlize flags, of state variable (sv)'s value agreeing with definition of state (s)

% Frequency estimation
for mtype = 1:NT
    
    for state = 1:128       % For states in which Ni = 0 or 1

        for sv = 1:2        % Values of (Ni,Nj) should exactly match def. of state (s)        
           z(:,sv) = grid(state,sv) * l;               % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
           k(:,sv) = 1*(RHS(:,sv) == z(:,sv));    % =1 if state variable (sv)'s value in data agrees with def. of state (s)
        end

        for sv = 3:4        % Values of (dz1,dz2) just need to be "adjacent" to state (s)
            z(:,sv) = grid(state,sv) * l;              % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
            z01(:,sv) = (grid(state,sv) + 1) * l;      % dz1 or dz2 can take a higher value.
            z02(:,sv) = (grid(state,sv) - 1) * l;      % dz1 or dz2 can take a lower value.
            k(:,sv) = 1*(RHS(:,sv) == z(:,sv) | RHS(:,sv) == z01(:,sv) | RHS(:,sv) == z02(:,sv));   % =1 if state variable's value "fuzzily" agrees with state (s)
        end

        kt = k';        % Transpose: [MTI x SV] --> [SV x MTI]
        K = prod(kt)';  % Multiply flag elements, to focus on true flag (all state variables' values must agree with state definition)                              
        C = sum(K);     % Count the number of times state (s) is reached in data.                             
        C_other(state) = C;   % For diagnostic purposes
        w = K/C;        % Frequency weight: Each data point is just one of the D times that state (s) is observed in data.
        
        q = repmat(Q(:,mtype),T*4,1);     % Arcidiacono-Miller weighting, for 4 firms' data (different matrix size from McDonald's)
        
        f_minus = 1 * (LHS < 0) .* w .* q;     % Count of choice == exit/reduce.
        f_plus  = 1 * (LHS > 0) .* w .* q;     % Count of choice == enter/add.
        p_minus = sum(f_minus);      % Frequency estimate: Choice prob of a = -1.
        p_plus = sum(f_plus);       % Frequency estimate: Choice prob of a = +1.
        p_zero = 1 - p_minus - p_plus;               % Choice prob of a = 0.
        
        p_other4 = [p_minus, p_zero, p_plus];
        P(2:5,:,state,mtype) = repmat(p_other4, 4, 1);
        
    end

    for state = 129:192     % For states in which Ni = 2 (need data from 'adjacent' state bins to mitigate 'NaN')

        for sv = 1:2        % Values of (Ni,Nj) should exactly match def. of state (s)        
           z(:,sv) = grid(state,sv) * l;               % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
           k(:,sv) = 1*(RHS(:,sv) == z(:,sv));    % =1 if state variable (sv)'s value in data agrees with def. of state (s)
        end

        for sv = 3:4        % Values of (dz1,dz2) can be anything.
            k(:,sv) = l;    % Flag is always =1 for any values of (dz1,dz2)
        end

        kt = k';        % Transpose: [MTI x SV] --> [SV x MTI]
        K = prod(kt)';  % Multiply flag elements, to focus on true flag (all state variables' values must agree with state definition)                              
        C = sum(K);     % Count the number of times state (s) is reached in data.                             
        C_mcd(state) = C;
        w = K/C;        % Frequency weight: Each data point is just one of the D times that state (s) is observed in data.
       
        q = repmat(Q(:,mtype),T*4,1);     % Arcidiacono-Miller weighting, for 4 firms' data (different matrix size from McDonald's)
        
        f_minus = 1 * (LHS < 0) .* w .* q;     % Count of choice == exit/reduce.
        f_plus  = 1 * (LHS > 0) .* w .* q;     % Count of choice == enter/add.
        p_minus = sum(f_minus);      % Frequency estimate: Choice prob of a = -1.
        p_plus = sum(f_plus);       % Frequency estimate: Choice prob of a = +1.
        p_zero = 1 - p_minus - p_plus;               % Choice prob of a = 0.
        
        p_other4 = [p_minus, p_zero, p_plus];
        P(2:5,:,state,mtype) = repmat(p_other4, 4, 1);
        
    end

    % Special treatment of the 'Ni = 3+' cases (very few observations)
    P(2:5,1,193:256,mtype) = P(2:5,1,129:192,mtype);    % Pr(-|Ni=3+) := Pr(-|Ni=2)
    P(2:5,2,193:256,mtype) = ones(4,1,64,1) - P(2:5,1,193:256,mtype);
    P(2:5,3,193:256,mtype) = zeros(4,1,64,1);         % Pr(+|Ni=3+) := 0 by modeling assumption
    
end

%% If 'NaN', Pr(+) = Pr(-) = 0, and Pr(0) = 1

Replace = P;
Replace(isnan(Replace)) = 0;
P = Replace;
P(:,2,:,:) = ones(I,1,NS,NT) - P(:,1,:,:) - P(:,3,:,:);
