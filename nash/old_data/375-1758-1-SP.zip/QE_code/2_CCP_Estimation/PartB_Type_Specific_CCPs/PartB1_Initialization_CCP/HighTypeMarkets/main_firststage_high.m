% Cannibal Burger.                                     
% By Mitsuru Igami and Nathan Yang.                    
% Main code first stage estimation in BBL.                               
% December 7, 2013.                                        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the states of the game.
load gamestates                 % Load state matrix (4*4*4*4, 4).
Ni = states(:,1);               % Number of own outlets: {0,1,2,3+}.
Nj = states(:,2);               % Number of rival outlets: {0,1,2,3+}.
dz1 = states(:,3);              % Discretized population state: {0,1,2,3}.
dz2 = states(:,4);              % Discretized income state: {0,1,2,3}.
S = size(states,1);             % Size of the statespace (4*4*4*4 = 256)

% Load the data.
load canadafastfood         % Load data matrix (with year-2005 obs dropped).
MT = size(data,1);          % Size of the dataset (M x T = 400 x 35 = 14000).
clusterid = data(:,1);      % Unique market ID.
year = data(:,2);           % Year.
N_aw = data(:,3);           % Number of A & W outlets (in data).
N_bk = data(:,4);           % Number of Burger King outlets (in data).
N_hvy = data(:,5);          % Number of Harvey's outlets (in data).
N_mcd = data(:,6);          % Number of McDonald's outlets (in data).
N_wdy = data(:,7);          % Number of Wendy's outlets (in data).
lagN_aw = data(:,8);        % Lagged number of outlets.
lagN_bk = data(:,9);        
lagN_hvy = data(:,10);      
lagN_mcd = data(:,11);      
lagN_wdy = data(:,12);      
fwdN_aw = data(:,13);       % Forward (next period) number of outlets.
fwdN_bk = data(:,14);       
fwdN_hvy = data(:,15);      
fwdN_mcd = data(:,16);      
fwdN_wdy = data(:,17);      
a_aw = data(:,18);          % Action (change in number of outlets) for A & W.
a_bk = data(:,19);          % Action (change in number of outlets) for Burger King.
a_hvy = data(:,20);         % Action (change in number of outlets) for Harvey's.    
a_mcd = data(:,21);         % Action (change in number of outlets) for McDonald's.
a_wdy = data(:,22);         % Action (change in number of outlets) for Wendy's.
fsaid = data(:,23);         % FSA ID.
pop = data(:,24);           % Population.
inc = data(:,26);           % Income
val = data(:,25);           % Property value
cityid = data(:,27);        % City id (?).

%% Variable construction.

% Number of own shops (in state space; capped at 3), from the perspective of each firm
Ni_aw = 1*(N_aw <= 3).*N_aw + 1*(N_aw > 3)*3;
Ni_bk = 1*(N_bk <= 3).*N_bk + 1*(N_bk > 3)*3;
Ni_hvy = 1*(N_hvy <= 3).*N_hvy + 1*(N_hvy > 3)*3;
Ni_mcd = 1*(N_mcd <= 3).*N_mcd + 1*(N_mcd > 3)*3;
Ni_wdy = 1*(N_wdy <= 3).*N_wdy + 1*(N_wdy > 3)*3;

% Number of rival shops (in state space; capped at 3), from the perspective of each firm
Nj_aw = N_bk + N_hvy + N_mcd + N_wdy;
Nj_bk = N_aw + N_hvy + N_mcd + N_wdy;
Nj_hvy = N_aw + N_bk + N_mcd + N_wdy;
Nj_mcd = N_aw + N_bk + N_hvy + N_wdy;
Nj_wdy = N_aw + N_bk + N_hvy + N_mcd;

Nj_aw = 1*(Nj_aw <= 3).*Nj_aw + 1*(Nj_aw > 3)*3;     
Nj_bk = 1*(Nj_bk <= 3).*Nj_bk + 1*(Nj_bk > 3)*3;
Nj_hvy = 1*(Nj_hvy <= 3).*Nj_hvy + 1*(Nj_hvy > 3)*3;
Nj_mcd = 1*(Nj_mcd <= 3).*Nj_mcd + 1*(Nj_mcd > 3)*3;
Nj_wdy = 1*(Nj_wdy <= 3).*Nj_wdy + 1*(Nj_wdy > 3)*3;

% Obtain 4 quantiles for main market characteristics.
pop25 = quantile(pop,0.25);   
inc25 = quantile(inc,0.25);  
pop50 = quantile(pop,0.5);  
inc50 = quantile(inc,0.5);  
pop75 = quantile(pop,0.75);   
inc75 = quantile(inc,0.75);   

o = ones(length(data),1);
disc_pop = o.*0.*(pop <= pop25) + o.*1.*(pop > pop25 & pop <= pop50) + o.*2.*(pop > pop50 & pop <= pop75) + o.*3.*(pop > pop75);  
disc_inc = o.*0.*(inc <= inc25) + o.*1.*(inc > inc25 & inc <= inc50) + o.*2.*(inc > inc50 & inc <= inc75) + o.*3.*(inc > inc75);  
 
% Define state variables for each firm
X_aw = [Ni_aw, Nj_aw, disc_pop, disc_inc];         % State for A & W.      
X_bk = [Ni_bk, Nj_bk, disc_pop, disc_inc];         % State for Burger King.      
X_hvy = [Ni_hvy, Nj_hvy, disc_pop, disc_inc];      % State for Harvey's.      
X_mcd = [Ni_mcd, Nj_mcd, disc_pop, disc_inc];      % State for McDonald's.      
X_wdy = [Ni_wdy, Nj_wdy, disc_pop, disc_inc];      % State for Wendy's.      

%% Construct CCPs for McDonald's.
X = X_mcd;                         % McDonald's states in data.
y = a_mcd;                         % McDonald's actions in data.
x = [Ni, Nj, dz1, dz2];            % State-space grid (S x SV = 256 x 4)  
P_mcd = zeros(S,3);                % Initialize policy function (State size * 3 actions)
D_mcd = zeros(S,1);                % Number of times certain state is reached. 

MTI = size(y,1);    % Size of effective data = M * T * I
SV = size(x,2);     % Number of state variables (4)
z = zeros(MTI,SV);  % Initialize matrix for checking if certain state is observed.
z01 = zeros(MTI,SV);% Initialize matrix for checking "adjacent states"
z02 = zeros(MTI,SV);% Initialize matrix for checking "adjacent states"
l = ones(MTI,1);    % Column vector of ones, for intermediate operations 
k = zeros(MTI,SV);  % Initizlize flags, of state variable (sv)'s value agreeing with definition of state (s)
bound = 1e-10;      % Threshold to filter-out negligible choice probabilities

for s = 1:128       % For states in which Ni = 0 or 1
    
    for sv = 1:2        % Values of (Ni,Nj) should exactly match def. of state (s)        
       z(:,sv) = x(s,sv) * l;               % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
       k(:,sv) = 1*(X(:,sv) == z(:,sv));    % =1 if state variable (sv)'s value in data agrees with def. of state (s)
    end
    
    for sv = 3:4        % Values of (dz1,dz2) just need to be "adjacent" to state (s)
        z(:,sv) = x(s,sv) * l;              % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
        z01(:,sv) = (x(s,sv) + 1) * l;      % dz1 or dz2 can take a higher value.
        z02(:,sv) = (x(s,sv) - 1) * l;      % dz1 or dz2 can take a lower value.
        k(:,sv) = 1*(X(:,sv) == z(:,sv) | X(:,sv) == z01(:,sv) | X(:,sv) == z02(:,sv));   % =1 if state variable's value "fuzzily" agrees with state (s)
    end
        
    kt = k';        % Transpose: [MTI x SV] --> [SV x MTI]
    K = prod(kt)';  % Multiply flag elements, to focus on true flag (all state variables' values must agree with state definition)                              
    D = sum(K);     % Count the number of times state (s) is reached in data.                             
    w = K/D;        % Frequency weight: Each data point is just one of the D times that state (s) is observed in data.
    D_mcd(s) = D;
    f_minus = 1 * (y < 0) .* w;     % Count of choice == exit/reduce.
    f_plus  = 1 * (y > 0) .* w;     % Count of choice == enter/add.
    P_mcd(s,1) = sum(f_minus);      % Frequency estimate: Choice prob of a = -1.
    P_mcd(s,3) = sum(f_plus);       % Frequency estimate: Choice prob of a = +1.
    P_mcd(s,2) = 1 - P_mcd(s,1) - P_mcd(s,3);               % Choice prob of a = 0.
    P_mcd(s,1) = 1*(abs(P_mcd(s,1)) > bound) * P_mcd(s,1);  % Set negligible prob to 0.
    P_mcd(s,2) = 1*(abs(P_mcd(s,2)) > bound) * P_mcd(s,2);  % Set negligible prob to 0.
    P_mcd(s,3) = 1*(abs(P_mcd(s,3)) > bound) * P_mcd(s,3);  % Set negligible prob to 0.
    
end

for s = 129:256     % For states in which Ni = 2 or 3+ (Ni=3+ cases will be further treated later)
    
    for sv = 1:2        % Values of (Ni,Nj) should exactly match def. of state (s)        
       z(:,sv) = x(s,sv) * l;               % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
       k(:,sv) = 1*(X(:,sv) == z(:,sv));    % =1 if state variable (sv)'s value in data agrees with def. of state (s)
    end
    
    for sv = 3:4        % Values of (dz1,dz2) can be anything.
        k(:,sv) = l;    % Flag is always =1 for any values of (dz1,dz2)
    end
        
    kt = k';        % Transpose: [MTI x SV] --> [SV x MTI]
    K = prod(kt)';  % Multiply flag elements, to focus on true flag (all state variables' values must agree with state definition)                              
    D = sum(K);     % Count the number of times state (s) is reached in data.                             
    w = K/D;        % Frequency weight: Each data point is just one of the D times that state (s) is observed in data.
    D_mcd(s) = D;
    f_minus = 1 * (y < 0) .* w;     % Count of choice == exit/reduce.
    f_plus  = 1 * (y > 0) .* w;     % Count of choice == enter/add.
    P_mcd(s,1) = sum(f_minus);      % Frequency estimate: Choice prob of a = -1.
    P_mcd(s,3) = sum(f_plus);       % Frequency estimate: Choice prob of a = +1.
    P_mcd(s,2) = 1 - P_mcd(s,1) - P_mcd(s,3);               % Choice prob of a = 0.
    P_mcd(s,1) = 1*(abs(P_mcd(s,1)) > bound) * P_mcd(s,1);  % Set negligible prob to 0.
    P_mcd(s,2) = 1*(abs(P_mcd(s,2)) > bound) * P_mcd(s,2);  % Set negligible prob to 0.
    P_mcd(s,3) = 1*(abs(P_mcd(s,3)) > bound) * P_mcd(s,3);  % Set negligible prob to 0.
    
end

%% Construct CCPs for other chains (A & W, Burger King, Harvey's, and Wendy's).
X = [X_aw; X_bk; X_hvy; X_wdy];  % Stack states in data.
y = [a_aw; a_bk; a_hvy; a_wdy];  % Stack actions in data.
x = [Ni, Nj, dz1, dz2];          % State-space grid.    
P_other = zeros(S,3);            % Initialize policy function (State size * 3 actions)
D_other = zeros(S,1);            % Stores a count of the number of times certain state reached.

MTI = size(y,1);    % Size of effective data = M * T * I
SV = size(x,2);     % Number of state variables (4)
z = zeros(MTI,SV);  % Initialize matrix for checking if certain state is observed.
z01 = zeros(MTI,SV);% Initialize matrix for checking "adjacent states"
z02 = zeros(MTI,SV);% Initialize matrix for checking "adjacent states"
l = ones(MTI,1);    % Column vector of ones, for intermediate operations 
k = zeros(MTI,SV);  % Initizlize flags, of state variable (sv)'s value agreeing with definition of state (s)
bound = 1e-10;      % Threshold to filter-out negligible choice probabilities

for s = 1:128       % For states in which Ni = 0 or 1
    
    for sv = 1:2        % Values of (Ni,Nj) should exactly match def. of state (s)        
       z(:,sv) = x(s,sv) * l;               % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
       k(:,sv) = 1*(X(:,sv) == z(:,sv));    % =1 if state variable (sv)'s value in data agrees with def. of state (s)
    end
    
    for sv = 3:4        % Values of (dz1,dz2) just need to be "adjacent" to state (s)
        z(:,sv) = x(s,sv) * l;              % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
        z01(:,sv) = (x(s,sv) + 1) * l;      % dz1 or dz2 can take a higher value.
        z02(:,sv) = (x(s,sv) - 1) * l;      % dz1 or dz2 can take a lower value.
        k(:,sv) = 1*(X(:,sv) == z(:,sv) | X(:,sv) == z01(:,sv) | X(:,sv) == z02(:,sv));   % =1 if state variable's value "fuzzily" agrees with state (s)
    end
        
    kt = k';        % Transpose: [MTI x SV] --> [SV x MTI]
    K = prod(kt)';  % Multiply flag elements, to focus on true flag (all state variables' values must agree with state definition)                              
    D = sum(K);     % Count the number of times state (s) is reached in data.                             
    w = K/D;        % Frequency weight: Each data point is just one of the D times that state (s) is observed in data.
    D_other(s) = D;
    f_minus = 1 * (y < 0) .* w;     % Count of choice == exit/reduce.
    f_plus  = 1 * (y > 0) .* w;     % Count of choice == enter/add.
    P_other(s,1) = sum(f_minus);      % Frequency estimate: Choice prob of a = -1.
    P_other(s,3) = sum(f_plus);       % Frequency estimate: Choice prob of a = +1.
    P_other(s,2) = 1 - P_other(s,1) - P_other(s,3);               % Choice prob of a = 0.
    P_other(s,1) = 1*(abs(P_other(s,1)) > bound) * P_other(s,1);  % Set negligible prob to 0.
    P_other(s,2) = 1*(abs(P_other(s,2)) > bound) * P_other(s,2);  % Set negligible prob to 0.
    P_other(s,3) = 1*(abs(P_other(s,3)) > bound) * P_other(s,3);  % Set negligible prob to 0.
    
end

for s = 129:256     % For states in which Ni = 2 or 3+ (Ni=3+ cases will be further treated later)
    
    for sv = 1:2        % Values of (Ni,Nj) should exactly match def. of state (s)        
       z(:,sv) = x(s,sv) * l;               % [MTIx1]-vector copy of state variable (sv)'s value in state (s), for flagging purposes
       k(:,sv) = 1*(X(:,sv) == z(:,sv));    % =1 if state variable (sv)'s value in data agrees with def. of state (s)
    end
    
    for sv = 3:4        % Values of (dz1,dz2) can be anything.
        k(:,sv) = l;    % Flag is always =1 for any values of (dz1,dz2)
    end
        
    kt = k';        % Transpose: [MTI x SV] --> [SV x MTI]
    K = prod(kt)';  % Multiply flag elements, to focus on true flag (all state variables' values must agree with state definition)                              
    D = sum(K);     % Count the number of times state (s) is reached in data.                             
    w = K/D;        % Frequency weight: Each data point is just one of the D times that state (s) is observed in data.
    D_other(s) = D;
    f_minus = 1 * (y < 0) .* w;     % Count of choice == exit/reduce.
    f_plus  = 1 * (y > 0) .* w;     % Count of choice == enter/add.
    P_other(s,1) = sum(f_minus);      % Frequency estimate: Choice prob of a = -1.
    P_other(s,3) = sum(f_plus);       % Frequency estimate: Choice prob of a = +1.
    P_other(s,2) = 1 - P_other(s,1) - P_other(s,3);               % Choice prob of a = 0.
    P_other(s,1) = 1*(abs(P_other(s,1)) > bound) * P_other(s,1);  % Set negligible prob to 0.
    P_other(s,2) = 1*(abs(P_other(s,2)) > bound) * P_other(s,2);  % Set negligible prob to 0.
    P_other(s,3) = 1*(abs(P_other(s,3)) > bound) * P_other(s,3);  % Set negligible prob to 0.
    
end

%% Clean up Ni=3+ cases and NaN's

P_mcd(193:256,3) = zeros(64,1);     % Pr(+|Ni=3+) := 0
P_other(193:256,3) = zeros(64,1);   % Pr(+|Ni=3+) := 0
P_mcd(193:256,1) = P_mcd(129:192,1);        % Pr(-|Ni=3+) = Pr(-|Ni=2)
P_other(193:256,1) = P_other(129:192,1);    % Pr(-|Ni=3+) = Pr(-|Ni=2)

% Pr(+) = 0 & Pr(-) = 0 if NaN [SAME AS BASELINE, BUT DIFFERENT FROM "LOW" or "MID" CASE]
a = P_mcd;
a(isnan(a)) = 0;
P_mcd = a;

a = P_other;
a(isnan(a)) = 0;
P_other = a;

% Pr(0) = 1 - Pr(-) - Pr(+)
P_mcd(:,2) = ones(S,1) - P_mcd(:,1) - P_mcd(:,3);     
P_other(:,2) = ones(S,1) - P_other(:,1) - P_other(:,3);

%% Store the first stage results.

% CCPs.
save('P_mcd.mat','P_mcd');           % Save the CCP matrix for McDonald's.
save('P_other.mat','P_other');       % Save the CCP matrix for other chains.

csvwrite('P_mcd.csv', P_mcd);        % Save the CCP matrix for McDonald's as csv file.
csvwrite('P_other.csv', P_other);    % Save the CCP matrix for other chains as csv file.

% Number of times state reached for weighting purposes.
save('D_mcd.mat','D_mcd');           % Save the number of times each state is reached for McDonald's.
save('D_other.mat','D_other');       % Save the number of times each state is reached for other chains.

csvwrite('D_mcd.csv', D_mcd);        % Save the number of times each state is reached for McDonald's as csv file.
csvwrite('D_other.csv', D_other);    % Save the number of times each state is reached for other chains as csv file.
