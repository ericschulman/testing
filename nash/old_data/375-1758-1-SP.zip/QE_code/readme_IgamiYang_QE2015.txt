Igami, Mitsuru, and Nathan Yang (2015), Unobserved Heterogeneity in Dynamic Games: Cannibalization and Preemptive Entry of Hamburger Chains in Canada, Quantitative Economics, Forthcoming

***

>> If you use the results, data, and/or Matlab code contained in this .zip file for your research, please use the reference above in your work

>> This readme file describes each of the folders that contain key files needed to replicate results in the paper

***

1_Data: Data files

>> Contains the data-set used for analysis throughout the paper in either Stata (.dta) and Excel (.xlsx) format.

***

2_CCP_Estimation: Non-parametric first-stage estimation of CCPs

>> PartA_Number_Types: Number of unobserved market types (Kasahara and Shimotsu, 2009)

The key files in this folder are as follows:

- main.m = Obtains the (minimum) number of unobserved market types across a set of fixed states, where the main output is KS_types.mat (or KS_types.csv)

- main_mixture.m = Code that makes use of the Kasahara and Shimotsu (2009) factorization result that may be used to initialize the Arcidiacono and Miller (2011) Expectation-Maximization method, used in the subsequent steps of CCP estimation, where the main output is Vmatrix.mat (or Vmatrix.csv) and Pi_init.mat (or Pi_init.csv)

>> PartB_Type_Specific_CCPs: Estimation of CCPs to allow for unobserved heterogeneity

... PartB1_Initialization_CCP: Arcidiacono and Miller (2011) method requires initial set of CCPs, which are obtained based on initial categorization of "low", "mid", and "high" type markets, as determined based on the distribution of market fixed effects from earlier reduced form analysis (see subfolder SplitDataByMktType)

... PartB2_Expectation_Maxmization: Implements the Arcidiacono and Miller (2011) method

The key files in this folder are as follows:

- main.m: Using the initial CCPs from PartB1_Type_Specific_CCPs, as well as the factorization result from Kasahara and Shimotsu (2009), this algorithm obtains the market-type-specific CCPs using the iterative Expectation-Maximization method, where the key outputs are Q_new.mat, Pi_new.mat, and P_mcd_[low/mid/high].mat

***

3_BBL_Estimation: Second-stage estimation using forward simulation

>> PartA_3_Unobserved_Types_Baseline: Baseline estimation using Bajari, Benkard, and Levin (2007) with 3 unobserved types

The key files in this folder are as follows:

- main_secondstage_calibrate15.m: Using Pi_init.mat (from Kasahara and Shimotsu), as well as Q_new.mat and P_mcd_[low/mid/high].mat (from Arcidiacono and Miller), this algorithm implements the forward simulations along with minimum distance estimation, where the main outputs are Psi_kappa0_mcd_cal15.mat (for McDonald's) and Psi_kappa0_other_cal15.mat (for the other chains)

- main_bootstrap.m: Bootstrapping algorithm used to obtain standard errors, which are ammended with the structural estimates to form the output files PsiB_bootstrap_am_se_mcd.tex (for McDonald's) and PsiB_bootstrap_am_se_other.tex (for the other chains)

>> PartA_1_Unobserved_Types_Baseline: Baseline estimation using Bajari, Benkard, and Levin (2007) with 1 unobserved types

The key files are the same as in PartA_3_Unobserved_Types_Baseline

>> PartA_2_Unobserved_Types_Baseline: Baseline estimation using Bajari, Benkard, and Levin (2007) with 2 unobserved types

The key files are the same as in PartA_3_Unobserved_Types_Baseline

>> PartA_4_Unobserved_Types_Baseline: Baseline estimation using Bajari, Benkard, and Levin (2007) with 4 unobserved types

The key files are the same as in PartA_3_Unobserved_Types_Baseline

***

4_Counterfactuals: Compare equilibrium with hypothetical scenarios with no cannibalization or no preemption

>> PartA_Compute_Equilibrium: Computes the Markov Perfect Equilibrium (MPE) for the equilibrium, no cannibalization, and no preemption scenarios

... PartA1_MPE: Equilibrium scenario

The key files in this folder are as follows:

- main_mpe.m: Solves the dynamic game based on the structural parameters estimated via Kasahara and Shimotsu (2009), Arcidiacono and Miller (2011), and Bajari, Benkard, and Levin (2007), where the main outputs are solved CCPs P_mcd_mpe.mat (for McDonald's) and P_other_mpe.mat (for other chains)

... PartA2_No_Cannibalization: No cannibalization scenario

The key files in this folder are as follows:

- main_mpe.m: Solves the dynamic game in a scenario with no cannibalization based on the structural parameters estimated via Kasahara and Shimotsu (2009), Arcidiacono and Miller (2011), and Bajari, Benkard, and Levin (2007), where the main outputs are solved CCPs P_mcd_mpe.mat (for McDonald's) and P_other_mpe.mat (for other chains)

... PartA3_No_Preemption: No preemption scenario

The key files in this folder are as follows:

- main_robot.m: Solves the dynamic game in a scenario with no preemptive motives (for McDonald's) based on the structural parameters estimated via Kasahara and Shimotsu (2009), Arcidiacono and Miller (2011), and Bajari, Benkard, and Levin (2007), where the main outputs are solved CCPs P_mcd_cf.mat (for McDonald's) and P_other_cf.mat (for other chains)

>> PartB_Plot_Trajectories: Compares outlet growth trajectories across various scenarios

The key files in this folder are as follows:

- main_compare.m: Forward simulates and compares the number of outlets based on the equilibrium, no cannibalization, and no preemption MPEs
