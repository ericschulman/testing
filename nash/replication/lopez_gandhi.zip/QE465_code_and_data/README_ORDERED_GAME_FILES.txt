
These programs were used in the paper "Estimation of Games with Ordered Actions: An Application to Chain-Store Entry". 
They are written in GAUSS and they were run in GAUSS 16. Older versions of GAUSS may lack the memory requirements to run these programs.
The programs are described as follows:

* The file "empirical_example_main_program.g" was used in our empirical application example. It uses the data file "data_pharmacies_sept_2012.asc"

* The file "empirical_example_binary_game_program.g" was used to generate the results of the game that treats entry as a binary choice decision. It also
uses the data file "data_pharmacies_sept_2012.asc"

* The file "monte_carlos_main_program.g" was used in our Monte Carlo experiment section.

*The file "monte_carlos_violated_assumptions.g" was used in the Monte Carlo experiment subsection where we explored the properties of our method when the 
main assumptions are violated.

